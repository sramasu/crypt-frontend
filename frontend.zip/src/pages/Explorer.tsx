import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Activity as ActivityIcon,
  Clock3,
  Filter,
  GitBranch,
  Network,
  Radar,
  ScanSearch,
  Search,
} from 'lucide-react';
import { api } from '../lib/api';
import { Badge, Btn, Empty, ErrBox, Glass, PageHeader, RiskGauge, SectionTitle, Skeleton, TableSkeleton, useToast } from '../components/ui';
import NetworkCanvas from '../components/NetworkCanvas';
import WagonWheel from '../components/WagonWheel';
import { MiniBars } from '../components/charts';
import TemporalTab from '../components/explorer/TemporalTab';
import PipelineTab from '../components/explorer/PipelineTab';
import { cls, fmtBTC, fmtNum, riskTone, shortHash, timeAgo } from '../lib/format';
import { CHAIN_TONE } from '../lib/palette';
import type { AddressRow, FlowRow, GEdge, GNode, TxRow } from '../lib/types';

const SHOWCASE = 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh';

const TABS = [
  { id: 'graph', label: 'Visual Graph & Wagon Wheel', icon: Network },
  { id: 'activity', label: 'Activity & Filtered Browsing', icon: ActivityIcon },
  { id: 'temporal', label: 'Temporal Analysis & 11 Motifs', icon: Clock3 },
  { id: 'pipeline', label: 'Pipeline Forensics', icon: GitBranch },
] as const;

type TabId = (typeof TABS)[number]['id'];

export default function Explorer() {
  const [addresses, setAddresses] = useState<AddressRow[]>([]);
  const [selected, setSelected] = useState<string>(SHOWCASE);
  const [kpi, setKpi] = useState<AddressRow | null>(null);
  const [wheel, setWheel] = useState<{ center: any; destinations: FlowRow[] } | null>(null);
  const [graph, setGraph] = useState<{ nodes: GNode[]; edges: GEdge[] } | null>(null);
  const [txs, setTxs] = useState<TxRow[]>([]);
  const [tab, setTab] = useState<TabId>('graph');
  const [loading, setLoading] = useState(true);
  const [kpiLoading, setKpiLoading] = useState(true);
  const [txLoading, setTxLoading] = useState(true);
  const [err, setErr] = useState('');
  const toast = useToast();

  /* search + filter state */
  const [addrQuery, setAddrQuery] = useState('');
  const [hashQuery, setHashQuery] = useState('');
  const [chain, setChain] = useState('all');
  const [win, setWin] = useState('all');
  const [op, setOp] = useState('>');
  const [amount, setAmount] = useState('');
  const [asset, setAsset] = useState('all');
  const [regQuery, setRegQuery] = useState('');

  /* initial: registry + graph */
  useEffect(() => {
    (async () => {
      try {
        const [a, g] = await Promise.all([api('/api/explorer/addresses'), api('/api/subgraph?format=json')]);
        setAddresses(a);
        setGraph(g);
      } catch (ex: any) {
        setErr(ex.message ?? 'Explorer uplink failed');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  /* KPI ribbon + wagon wheel pivot */
  useEffect(() => {
    (async () => {
      setKpiLoading(true);
      try {
        const [rows, w] = await Promise.all([
          api(`/api/explorer/addresses?address=${encodeURIComponent(selected)}`),
          api(`/api/explorer/wagon-wheel?address=${encodeURIComponent(selected)}`),
        ]);
        setKpi(rows[0] ?? null);
        setWheel(w);
      } catch (ex: any) {
        toast.push(ex.message ?? 'Address resolution failed', 'red');
      } finally {
        setKpiLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected]);

  /* filtered transaction browsing */
  const loadTxs = async () => {
    setTxLoading(true);
    try {
      const p = new URLSearchParams({ window: win, asset, op, amount, search: hashQuery });
      setTxs(await api(`/api/explorer/transactions?${p.toString()}`));
    } catch (ex: any) {
      toast.push(ex.message ?? 'Transaction query failed', 'red');
    } finally {
      setTxLoading(false);
    }
  };
  useEffect(() => {
    loadTxs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [win, asset]);

  const applySearch = () => {
    if (addrQuery.trim()) {
      const q = addrQuery.trim().toLowerCase();
      const hit = addresses.find((a) => a.address.toLowerCase().includes(q));
      setSelected(hit ? hit.address : addrQuery.trim());
      toast.push(hit ? `Pivoted to ${shortHash(hit.address, 8)}` : 'Address not indexed — probing anyway', hit ? 'cyan' : 'amber');
    }
    loadTxs();
  };

  const registry = useMemo(
    () =>
      addresses.filter(
        (a) =>
          (chain === 'all' || a.chain === chain) &&
          (!regQuery || a.address.toLowerCase().includes(regQuery.toLowerCase()) || a.category.toLowerCase().includes(regQuery.toLowerCase())),
      ),
    [addresses, chain, regQuery],
  );

  /* activity charts derived from filtered txs */
  const freq = useMemo(() => {
    const m = new Map<string, number>();
    txs.forEach((t) => {
      const d = t.timestamp.slice(5, 10);
      m.set(d, (m.get(d) ?? 0) + 1);
    });
    return Array.from(m.entries()).map(([day, count]) => ({ day, count }));
  }, [txs]);

  const feeHist = useMemo(() => {
    const buckets = new Array(8).fill(0);
    const max = Math.max(...txs.map((t) => t.fee * 1e8), 1);
    txs.forEach((t) => {
      const i = Math.min(7, Math.floor(((t.fee * 1e8) / max) * 8));
      buckets[i] += 1;
    });
    return buckets.map((count, i) => ({ bucket: `${Math.round((max / 8) * i)}–${Math.round((max / 8) * (i + 1))}`, count }));
  }, [txs]);

  return (
    <div>
      <PageHeader
        title="Wallet Explorer / Intelligence"
        sub="Address-level attribution, radial flow decomposition and forensic graph inspection"
      />

      {err && <ErrBox msg={err} />}

      {/* Search & filter bar */}
      <Glass className="p-4 mb-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
          <div className="lg:col-span-4 relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
            <input
              className="field font-mono2 !pl-8"
              placeholder="Search address (bc1q… / 0x…)"
              value={addrQuery}
              onChange={(e) => setAddrQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && applySearch()}
              spellCheck={false}
            />
          </div>
          <div className="lg:col-span-4 relative">
            <ScanSearch size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
            <input
              className="field font-mono2 !pl-8"
              placeholder="Search transaction hash"
              value={hashQuery}
              onChange={(e) => setHashQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && applySearch()}
              spellCheck={false}
            />
          </div>
          <div className="lg:col-span-2">
            <select className="field" value={chain} onChange={(e) => setChain(e.target.value)}>
              <option value="all">All Chains</option>
              <option value="Bitcoin">Bitcoin</option>
              <option value="Ethereum">Ethereum</option>
              <option value="Tether">Tether</option>
            </select>
          </div>
          <div className="lg:col-span-2">
            <Btn onClick={applySearch} className="w-full">
              <Filter size={13} /> Apply
            </Btn>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)] mr-1">Window</span>
          {[
            ['24h', '24h'],
            ['7d', '7d'],
            ['30d', '30d'],
            ['all', 'All'],
          ].map(([v, l]) => (
            <button
              key={v}
              onClick={() => setWin(v)}
              className={cls(
                'px-3 py-1.5 rounded-lg text-[10px] font-semibold uppercase tracking-wider border transition-all',
                win === v ? 'bg-cyan-400/15 text-cyan-300 border-cyan-400/40' : 'text-[var(--muted)] border-[var(--border)] hover:bg-[var(--panel-soft)]',
              )}
            >
              {l}
            </button>
          ))}
          <span className="w-px h-5 bg-[var(--border)] mx-1 hidden sm:block" />
          <span className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)] mr-1">Amount</span>
          <select className="field !w-16 !py-1.5" value={op} onChange={(e) => setOp(e.target.value)}>
            <option value="&gt;">&gt;</option>
            <option value="&lt;">&lt;</option>
            <option value="=">=</option>
          </select>
          <input
            className="field !w-28 !py-1.5 font-mono2"
            placeholder="0.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && applySearch()}
          />
          <span className="w-px h-5 bg-[var(--border)] mx-1 hidden sm:block" />
          <span className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)] mr-1">Token</span>
          <select className="field !w-28 !py-1.5" value={asset} onChange={(e) => setAsset(e.target.value)}>
            <option value="all">All tokens</option>
            <option value="BTC">BTC</option>
            <option value="ETH">ETH</option>
            <option value="USDT">USDT</option>
          </select>
        </div>
      </Glass>

      {/* KPI ribbon */}
      <Glass className="p-4 mb-5">
        {kpiLoading ? (
          <Skeleton className="h-24" />
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4 items-center">
            <div className="col-span-2 md:col-span-1 flex justify-center">
              <RiskGauge value={kpi?.risk_index ?? 0} />
            </div>
            <div>
              <div className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)]">Unspent Balance</div>
              <div className="font-mono2 text-lg font-bold mt-1">{fmtBTC(kpi?.balance)}</div>
              <div className="text-[10px] text-[var(--muted)] font-mono2 mt-0.5">{kpi ? shortHash(kpi.address, 10) : '—'}</div>
            </div>
            <div>
              <div className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)]">Cumulative Turnover</div>
              <div className="font-mono2 text-lg font-bold mt-1">{fmtBTC(kpi?.turnover, 2)}</div>
              <div className="text-[10px] text-[var(--muted)] mt-0.5">lifetime routed volume</div>
            </div>
            <div>
              <div className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)]">Peak Transfer</div>
              <div className="font-mono2 text-lg font-bold mt-1 text-amber-300">{fmtBTC(kpi?.peak_transfer, 2)}</div>
              <div className="text-[10px] text-[var(--muted)] mt-0.5">largest single outflow</div>
            </div>
            <div>
              <div className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)]">Associated Entity Group</div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {kpi?.cluster_id ? <Badge tone="purple">{kpi.cluster_id}</Badge> : <Badge tone="slate">UNCLUSTERED</Badge>}
                {kpi && <Badge tone={riskTone(kpi.risk_index)}>{kpi.category}</Badge>}
              </div>
              <div className="text-[10px] text-[var(--muted)] mt-1.5">{kpi?.cluster_name ?? 'no attribution'}</div>
            </div>
          </div>
        )}
      </Glass>

      {/* Tab bar */}
      <div className="flex gap-1.5 mb-5 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cls(
              'flex items-center gap-2 px-4 py-2.5 rounded-xl text-[11px] font-semibold tracking-wide whitespace-nowrap border transition-all',
              tab === t.id
                ? 'bg-cyan-400/12 text-cyan-300 border-cyan-400/40 shadow-[0_0_18px_-6px_rgba(0,229,255,0.5)]'
                : 'text-[var(--muted)] border-[var(--border)] hover:bg-[var(--panel-soft)] hover:text-[var(--text)]',
            )}
          >
            <t.icon size={14} />
            {t.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={tab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.22 }}>
          {tab === 'graph' && (
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              <Glass className="p-5">
                <SectionTitle
                  icon={Radar}
                  title="Radial Wagon Wheel"
                  sub="counterparty flow shares around the pivot address"
                  right={wheel && <Badge tone="cyan">{wheel.destinations.length} destinations</Badge>}
                />
                {kpiLoading ? (
                  <Skeleton className="h-[440px]" />
                ) : (
                  <WagonWheel center={wheel?.center ?? kpi} destinations={wheel?.destinations ?? []} onSelect={(a) => setSelected(a)} />
                )}
              </Glass>
              <Glass className="p-5">
                <SectionTitle
                  icon={Network}
                  title="Interactive Network Graph"
                  sub="force-directed · drag nodes · scroll to zoom · hover for intel"
                  right={<Badge tone="emerald">physics live</Badge>}
                />
                {loading ? (
                  <Skeleton className="h-[440px]" />
                ) : graph ? (
                  <NetworkCanvas nodes={graph.nodes} edges={graph.edges} onSelect={(id) => setSelected(id)} />
                ) : (
                  <Empty msg="Sub-graph payload unavailable." />
                )}
                <p className="mt-3 text-[10px] text-[var(--muted)] font-mono2">
                  vis.js-compatible dataset served at <span className="text-cyan-400">GET /api/subgraph?format=json</span> · standalone renderer at{' '}
                  <span className="text-cyan-400">GET /api/subgraph</span>
                </p>
              </Glass>
            </div>
          )}

          {tab === 'activity' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                <Glass className="p-5">
                  <SectionTitle icon={ActivityIcon} title="Daily Transaction Frequency" sub={`window: ${win} · token: ${asset}`} />
                  {txLoading ? <Skeleton className="h-[200px]" /> : freq.length ? <MiniBars data={freq} xKey="day" yKey="count" color="#00E5FF" /> : <Empty msg="No transactions in this window." />}
                </Glass>
                <Glass className="p-5">
                  <SectionTitle icon={Clock3} title="Fee Distribution" sub="satoshi fee buckets across filtered set" />
                  {txLoading ? <Skeleton className="h-[200px]" /> : txs.length ? <MiniBars data={feeHist} xKey="bucket" yKey="count" color="#a855f7" /> : <Empty msg="No fee samples in this window." />}
                </Glass>
              </div>

              <Glass className="p-0 overflow-hidden">
                <div className="p-5 pb-3 flex flex-wrap items-center justify-between gap-3">
                  <SectionTitle icon={ScanSearch} title="Address Registry" sub={`${registry.length} indexed entities`} />
                  <div className="relative w-64">
                    <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
                    <input className="field !pl-8 !py-2" placeholder="Filter registry…" value={regQuery} onChange={(e) => setRegQuery(e.target.value)} />
                  </div>
                </div>
                {loading ? (
                  <TableSkeleton rows={8} />
                ) : (
                  <div className="overflow-x-auto max-h-[440px] overflow-y-auto">
                    <table className="table-base w-full">
                      <thead className="sticky top-0 bg-[var(--panel-solid)] z-10">
                        <tr>
                          <th>Address</th>
                          <th>Chain</th>
                          <th>Category</th>
                          <th>Risk</th>
                          <th className="text-right">Balance</th>
                          <th className="text-right">Turnover</th>
                          <th>Cluster</th>
                          <th className="text-right">Last Active</th>
                        </tr>
                      </thead>
                      <tbody>
                        {registry.map((a) => (
                          <tr key={a.id} className="cursor-pointer" onClick={() => { setSelected(a.address); toast.push(`Pivot: ${shortHash(a.address, 8)}`); }}>
                            <td className="font-mono2 text-cyan-300">{shortHash(a.address, 10)}</td>
                            <td><Badge tone={CHAIN_TONE[a.chain] ?? 'slate'}>{a.chain}</Badge></td>
                            <td className="text-[11px]">{a.category}</td>
                            <td><Badge tone={riskTone(a.risk_index)}>{a.risk_index.toFixed(2)}</Badge></td>
                            <td className="text-right font-mono2">{fmtBTC(a.balance, 2)}</td>
                            <td className="text-right font-mono2">{fmtNum(Math.round(a.turnover))}</td>
                            <td>{a.cluster_id ? <Badge tone="purple">{a.cluster_id}</Badge> : <span className="text-[var(--muted)]">—</span>}</td>
                            <td className="text-right font-mono2 text-[10px] text-[var(--muted)]">{timeAgo(a.last_active)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </Glass>
            </div>
          )}

          {tab === 'temporal' && <TemporalTab />}
          {tab === 'pipeline' && <PipelineTab selected={selected} />}
        </motion.div>
      </AnimatePresence>

      {toast.node}
    </div>
  );
}

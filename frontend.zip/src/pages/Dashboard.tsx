import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  AlertTriangle,
  ArrowLeftRight,
  Bell,
  Boxes,
  BrainCircuit,
  PieChart as PieIcon,
  ShieldAlert,
  TrendingUp,
  Wallet,
  Waves,
} from 'lucide-react';
import { api } from '../lib/api';
import { Badge, ConfPill, Empty, ErrBox, Glass, PageHeader, SectionTitle, Skeleton, Stat as StatLike, TableSkeleton } from '../components/ui';
import { AssetDonut, VolumeTrendChart } from '../components/charts';
import Globe3D from '../components/Globe3D';
import { fmtBTC, fmtNum, riskTone, sevTone, shortHash, timeAgo } from '../lib/format';
import { CHAIN_TONE } from '../lib/palette';
import type { AddressRow, ClusterRow, MembershipRow, SecurityEvent, TxRow } from '../lib/types';

export default function Dashboard() {
  const [status, setStatus] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [high, setHigh] = useState<{ flagged_addresses: AddressRow[]; whale_transactions: TxRow[]; high_risk_groups: ClusterRow[] } | null>(null);
  const [members, setMembers] = useState<MembershipRow[]>([]);
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [err, setErr] = useState('');

  const loading = !status || !stats || !high;

  useEffect(() => {
    (async () => {
      try {
        const [s, d, h, m, e] = await Promise.all([
          api('/api/status'),
          api('/api/db/stats'),
          api('/api/dashboard/high-risk'),
          api('/api/dashboard/group-memberships'),
          api('/api/dashboard/security-events'),
        ]);
        setStatus(s);
        setStats(d);
        setHigh(h);
        setMembers(m);
        setEvents(e);
      } catch (ex: any) {
        setErr(ex.message ?? 'Telemetry uplink failed');
      }
    })();
  }, []);

  /* live security feed poll */
  useEffect(() => {
    const i = setInterval(async () => {
      try {
        setEvents(await api('/api/dashboard/security-events'));
      } catch {
        /* keep last frame */
      }
    }, 15000);
    return () => clearInterval(i);
  }, []);

  return (
    <div>
      <PageHeader
        title="Executive Telemetry"
        sub="Cross-chain entity resolution posture — hybrid sub-graph GNN over 6 resolved entity clusters"
        right={
          stats && (
            <div className="hidden xl:flex items-center gap-2 text-[10px] font-mono2 text-[var(--muted)]">
              <Badge tone="emerald">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 live-dot" /> {status?.status ?? 'OPERATIONAL'}
              </Badge>
              <span>
                PG · {fmtNum(stats.addresses)} addr · {fmtNum(stats.transactions)} tx · {stats.rules} rules · {stats.alerts} alerts
              </span>
            </div>
          )
        }
      />

      {err && <ErrBox msg={err} />}

      {/* 3D command hero */}
      <Glass className="mb-5 relative overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(520px 220px at 14% 50%, rgba(0,229,255,0.09), transparent 70%)' }}
        />
        <div className="relative flex flex-col md:flex-row items-center gap-5 p-5 md:p-6">
          <Globe3D size={150} />
          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 live-dot" />
              <span className="text-[10px] font-mono2 tracking-[0.24em] text-emerald-400 uppercase">Forensic grid online</span>
            </div>
            <h2 className="text-xl md:text-2xl font-extrabold tracking-tight text-aurora inline-block">Global Entity Resolution Mesh</h2>
            <p className="text-[11px] text-[var(--muted)] mt-1.5 max-w-xl leading-relaxed">
              Live sub-graph telemetry across the BTC · ETH · USDT rails — heuristic attribution, hybrid GNN linkage and UTXO
              taint propagation fused into a single command deck.
            </p>
          </div>
          <div className="grid grid-cols-3 md:grid-cols-1 gap-2 font-mono2 w-full md:w-auto">
            <div className="glass rounded-xl px-3.5 py-2 text-center md:text-right">
              <div className="text-[8px] uppercase tracking-[0.18em] text-[var(--muted)]">Uptime</div>
              <div className="text-xs font-bold text-cyan-300">{status?.uptime ?? '99.982%'}</div>
            </div>
            <div className="glass rounded-xl px-3.5 py-2 text-center md:text-right">
              <div className="text-[8px] uppercase tracking-[0.18em] text-[var(--muted)]">Engine</div>
              <div className="text-xs font-bold text-purple-300">POSTGRES</div>
            </div>
            <div className="glass rounded-xl px-3.5 py-2 text-center md:text-right">
              <div className="text-[8px] uppercase tracking-[0.18em] text-[var(--muted)]">GNN F1</div>
              <div className="text-xs font-bold text-amber-300">{status ? `${status.totals.gnn_f1.toFixed(1)}%` : '87.4%'}</div>
            </div>
          </div>
        </div>
      </Glass>

      {/* KPI grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-5">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32" />)
        ) : (
          <>
            <StatLike icon={ArrowLeftRight} label="Total Transactions" value={fmtNum(status.totals.transactions)} tone="cyan" sub={<Badge tone="emerald">+2.4% 24h</Badge>} />
            <StatLike icon={Wallet} label="Unique Addresses" value={fmtNum(status.totals.addresses)} tone="purple" sub={<Badge tone="cyan">indexed</Badge>} />
            <StatLike icon={Boxes} label="Formed Clusters" value={fmtNum(status.totals.clusters)} tone="emerald" sub={<span className="font-mono2 text-[10px] text-[var(--muted)]">C001–C006</span>} />
            <Glass hover className="p-5 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="p-2 rounded-xl border text-amber-400 bg-amber-400/10 border-amber-400/25">
                  <BrainCircuit size={17} />
                </span>
                <Badge tone="amber">Hybrid 19-dim</Badge>
              </div>
              <div className="mt-4 text-2xl font-bold font-mono2 metric-glow">{status.totals.gnn_f1.toFixed(1)}%</div>
              <div className="mt-1 text-[11px] uppercase tracking-[0.14em] text-[var(--muted)]">Sub-Graph GNN F1-Score</div>
              <div className="mt-2.5 h-1.5 rounded-full bg-[var(--panel-soft)] overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-amber-400 to-cyan-400"
                  initial={{ width: 0 }}
                  animate={{ width: `${status.totals.gnn_f1}%` }}
                  transition={{ duration: 1.1, ease: 'easeOut' }}
                />
              </div>
            </Glass>
          </>
        )}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-5">
        <Glass className="p-5 xl:col-span-2">
          <SectionTitle icon={TrendingUp} title="Transaction Volume Trends" sub="Monthly confirmed transactions per asset rail" />
          {loading ? <Skeleton className="h-[280px]" /> : <VolumeTrendChart data={status.volume_trend} />}
        </Glass>
        <Glass className="p-5">
          <SectionTitle icon={PieIcon} title="Asset Distribution" sub="Share of monitored transaction count" />
          {loading ? <Skeleton className="h-[280px]" /> : <AssetDonut data={status.distribution} />}
        </Glass>
      </div>

      {/* High-risk watchlist + live feed */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-5">
        <Glass className="p-0 overflow-hidden">
          <div className="p-5 pb-3">
            <SectionTitle icon={ShieldAlert} title="Flagged Addresses" sub="risk_index > 0.65 · last 48h" />
          </div>
          {loading ? (
            <TableSkeleton rows={6} />
          ) : (
            <div className="overflow-x-auto">
              <table className="table-base w-full">
                <thead>
                  <tr>
                    <th>Address</th>
                    <th>Chain</th>
                    <th>Risk</th>
                    <th className="text-right">Balance</th>
                  </tr>
                </thead>
                <tbody>
                  {high.flagged_addresses.map((a) => (
                    <tr key={a.id}>
                      <td>
                        <div className="font-mono2 text-cyan-300">{shortHash(a.address, 7)}</div>
                        <div className="text-[10px] text-[var(--muted)]">{a.category}</div>
                      </td>
                      <td>
                        <Badge tone={CHAIN_TONE[a.chain] ?? 'slate'}>{a.chain}</Badge>
                      </td>
                      <td>
                        <Badge tone={riskTone(a.risk_index)}>{a.risk_index.toFixed(2)}</Badge>
                      </td>
                      <td className="text-right font-mono2">{fmtBTC(a.balance, 2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Glass>

        <Glass className="p-0 overflow-hidden">
          <div className="p-5 pb-3">
            <SectionTitle icon={Waves} title="Whale / High-Risk TXs" sub="amount > 3.0 BTC · last 48h" />
          </div>
          {loading ? (
            <TableSkeleton rows={6} />
          ) : (
            <div className="overflow-x-auto">
              <table className="table-base w-full">
                <thead>
                  <tr>
                    <th>Hash</th>
                    <th className="text-right">Amount</th>
                    <th>Risk</th>
                    <th className="text-right">Age</th>
                  </tr>
                </thead>
                <tbody>
                  {high.whale_transactions.map((t) => (
                    <tr key={t.id}>
                      <td>
                        <div className="font-mono2 text-cyan-300">{shortHash(t.tx_hash, 6)}</div>
                        <div className="text-[10px] text-[var(--muted)] font-mono2">
                          {shortHash(t.from_address, 4)} → {shortHash(t.to_address, 4)}
                        </div>
                      </td>
                      <td className="text-right font-mono2 text-amber-300">{t.amount.toFixed(2)} ₿</td>
                      <td>
                        <Badge tone={sevTone(t.risk_level)}>{t.risk_level}</Badge>
                      </td>
                      <td className="text-right text-[var(--muted)] font-mono2 text-[10px]">{timeAgo(t.timestamp)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Glass>

        {/* Live security alert feed */}
        <Glass className="p-0 overflow-hidden flex flex-col">
          <div className="p-5 pb-3">
            <SectionTitle
              icon={Bell}
              title="Live Security Alert Feed"
              sub="event stream · 15s polling"
              right={
                <span className="flex items-center gap-1.5 text-[9px] font-mono2 text-emerald-400 tracking-widest">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 live-dot" /> STREAMING
                </span>
              }
            />
          </div>
          <div className="flex-1 overflow-y-auto px-3 pb-4 space-y-2 max-h-[380px]">
            {loading ? (
              <TableSkeleton rows={5} />
            ) : events.length === 0 ? (
              <Empty msg="No security events in the stream window." />
            ) : (
              events.map((e) => (
                <motion.div
                  key={e.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="glass rounded-xl p-3 border-l-2"
                  style={{ borderLeftColor: e.severity === 'HIGH' ? '#ef4444' : e.severity === 'MEDIUM' ? '#f59e0b' : '#10b981' }}
                >
                  <div className="flex items-center justify-between gap-2">
                    <Badge tone={sevTone(e.severity)}>{e.severity}</Badge>
                    <span className="font-mono2 text-[9px] text-[var(--muted)]">{timeAgo(e.created_at)}</span>
                  </div>
                  <div className="mt-1.5 text-xs font-semibold leading-snug">{e.title}</div>
                  <div className="mt-0.5 text-[10px] text-[var(--muted)] leading-snug">{e.description}</div>
                </motion.div>
              ))
            )}
          </div>
        </Glass>
      </div>

      {/* High-risk groups strip */}
      {!loading && high.high_risk_groups.length > 0 && (
        <Glass className="p-4 mb-5 flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-2 text-[10px] uppercase tracking-[0.16em] text-[var(--muted)] mr-2">
            <AlertTriangle size={13} className="text-red-400" /> High-Risk Entity Groups
          </span>
          {high.high_risk_groups.map((g) => (
            <Badge key={g.cluster_id} tone="red" className="!normal-case !tracking-normal !text-[10px]">
              {g.cluster_id} · {g.name}
            </Badge>
          ))}
        </Glass>
      )}

      {/* Group-membership confidence matrix */}
      <Glass className="p-0 overflow-hidden">
        <div className="p-5 pb-3">
          <SectionTitle icon={Boxes} title="Group-Membership Confidence Matrix" sub="heuristic attribution of addresses to entity clusters C001–C006" />
        </div>
        {loading ? (
          <TableSkeleton rows={8} />
        ) : (
          <div className="overflow-x-auto">
            <table className="table-base w-full">
              <thead>
                <tr>
                  <th>Address</th>
                  <th>Entity Group</th>
                  <th>Heuristic Rule</th>
                  <th>Confidence</th>
                </tr>
              </thead>
              <tbody>
                {members.map((m) => (
                  <tr key={m.id}>
                    <td className="font-mono2 text-cyan-300">{shortHash(m.address, 10)}</td>
                    <td>
                      <Badge tone="purple" className="mr-2">{m.cluster_id}</Badge>
                      <span className="text-[11px] text-[var(--muted)]">{m.cluster_name}</span>
                    </td>
                    <td className="text-[11px]">{m.heuristic}</td>
                    <td>
                      <ConfPill value={m.confidence} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Glass>
    </div>
  );
}

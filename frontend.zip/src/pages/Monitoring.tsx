import { useEffect, useState } from 'react';
import { Bell, Play, PlusCircle, ShieldAlert, SlidersHorizontal } from 'lucide-react';
import { api, post, put } from '../lib/api';
import { Badge, Btn, Empty, ErrBox, Glass, PageHeader, SectionTitle, TableSkeleton, Toggle, useToast } from '../components/ui';
import { cls, sevTone, shortHash, statusTone, timeAgo } from '../lib/format';
import type { AlertRow, RuleRow } from '../lib/types';

const FILTERS = ['all', 'new', 'acknowledged', 'resolved'] as const;

export default function Monitoring() {
  const [rules, setRules] = useState<RuleRow[]>([]);
  const [alerts, setAlerts] = useState<AlertRow[]>([]);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>('all');
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [evalBusy, setEvalBusy] = useState(false);
  const [createBusy, setCreateBusy] = useState(false);
  const [form, setForm] = useState({ name: '', target_type: 'risk_score', operator: '>=', threshold: '', severity: 'HIGH' });
  const [formErr, setFormErr] = useState('');
  const toast = useToast();

  const load = async (f = filter) => {
    try {
      const [r, a] = await Promise.all([api('/api/monitoring/rules'), api(`/api/monitoring/alerts?status=${f}`)]);
      setRules(r);
      setAlerts(a);
      setErr('');
    } catch (ex: any) {
      setErr(ex.message ?? 'Monitoring uplink failed');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load('all');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const switchFilter = (f: (typeof FILTERS)[number]) => {
    setFilter(f);
    load(f);
  };

  const evaluate = async () => {
    setEvalBusy(true);
    try {
      const r = await post<{ evaluated: number; new_alerts: number }>('/api/monitoring/evaluate', {});
      toast.push(
        r.new_alerts > 0
          ? `Rule evaluation complete — ${r.new_alerts} new alert${r.new_alerts === 1 ? '' : 's'} raised across ${r.evaluated} active rules`
          : `Rule evaluation complete — no new alerts (SHA-256 deduplication active)`,
        r.new_alerts > 0 ? 'amber' : 'emerald',
      );
      await load();
    } catch (ex: any) {
      toast.push(ex.message ?? 'Evaluation failed', 'red');
    } finally {
      setEvalBusy(false);
    }
  };

  const createRule = async () => {
    if (!form.name.trim()) return setFormErr('Rule name is required');
    if (!form.threshold.trim()) return setFormErr('Threshold value is required');
    setFormErr('');
    setCreateBusy(true);
    try {
      await post('/api/monitoring/rules', form);
      toast.push(`Rule "${form.name}" armed`);
      setForm({ name: '', target_type: 'risk_score', operator: '>=', threshold: '', severity: 'HIGH' });
      await load();
    } catch (ex: any) {
      setFormErr(ex.message ?? 'Failed to create rule');
    } finally {
      setCreateBusy(false);
    }
  };

  const toggleRule = async (rule: RuleRow, active: boolean) => {
    try {
      await put('/api/monitoring/rules', { rule_id: rule.rule_id, active });
      setRules((rs) => rs.map((r) => (r.rule_id === rule.rule_id ? { ...r, active } : r)));
      toast.push(`${rule.rule_id} ${active ? 'activated' : 'suspended'}`, active ? 'emerald' : 'amber');
    } catch (ex: any) {
      toast.push(ex.message ?? 'Toggle failed', 'red');
    }
  };

  const setStatus = async (alert: AlertRow, status: string) => {
    try {
      await post('/api/monitoring/alert-status', { alert_id: alert.alert_id, status });
      setAlerts((as) => as.map((a) => (a.alert_id === alert.alert_id ? { ...a, status } : a)));
      toast.push(`${alert.alert_id} → ${status}`);
    } catch (ex: any) {
      toast.push(ex.message ?? 'Status update failed', 'red');
    }
  };

  return (
    <div>
      <PageHeader
        title="Monitoring"
        sub="Deterministic surveillance rule engine — alerts deduplicated via SHA-256 subject hashing"
        right={
          <Btn onClick={evaluate} busy={evalBusy}>
            <Play size={13} /> Run Rule Evaluation Now
          </Btn>
        }
      />

      {err && <ErrBox msg={err} />}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-5">
        {/* Create rule */}
        <Glass className="p-5">
          <SectionTitle icon={PlusCircle} title="Create Monitoring Rule" sub="armed against live telemetry" />
          <div className="space-y-3">
            <div>
              <label className="text-[10px] uppercase tracking-[0.14em] text-[var(--muted)] block mb-1.5">Rule Name</label>
              <input className="field" placeholder="e.g. Dormant whale awakening" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] uppercase tracking-[0.14em] text-[var(--muted)] block mb-1.5">Target Type</label>
                <select className="field" value={form.target_type} onChange={(e) => setForm({ ...form, target_type: e.target.value })}>
                  <option value="risk_score">risk_score</option>
                  <option value="tx_value">tx_value</option>
                  <option value="group_member">group_member</option>
                  <option value="motif">motif</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-[0.14em] text-[var(--muted)] block mb-1.5">Operator</label>
                <select className="field" value={form.operator} onChange={(e) => setForm({ ...form, operator: e.target.value })}>
                  <option value="&gt;">&gt;</option>
                  <option value="&gt;=">&gt;=</option>
                  <option value="=">=</option>
                  <option value="in">in</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] uppercase tracking-[0.14em] text-[var(--muted)] block mb-1.5">Threshold Value</label>
                <input className="field font-mono2" placeholder="0.80 / 3.0 / C002" value={form.threshold} onChange={(e) => setForm({ ...form, threshold: e.target.value })} />
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-[0.14em] text-[var(--muted)] block mb-1.5">Severity</label>
                <select className="field" value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })}>
                  <option value="HIGH">HIGH</option>
                  <option value="MEDIUM">MEDIUM</option>
                  <option value="LOW">LOW</option>
                </select>
              </div>
            </div>
            {formErr && <p className="text-[11px] text-red-400">{formErr}</p>}
            <Btn onClick={createRule} busy={createBusy} className="w-full">
              <PlusCircle size={13} /> Arm Rule
            </Btn>
          </div>
        </Glass>

        {/* Active rules table */}
        <Glass className="p-0 overflow-hidden xl:col-span-2">
          <div className="p-5 pb-3">
            <SectionTitle icon={SlidersHorizontal} title="Active Surveillance Rules" sub={`${rules.filter((r) => r.active).length} of ${rules.length} rules armed`} />
          </div>
          {loading ? (
            <TableSkeleton rows={4} />
          ) : rules.length === 0 ? (
            <Empty msg="No surveillance rules defined." />
          ) : (
            <div className="overflow-x-auto">
              <table className="table-base w-full">
                <thead>
                  <tr>
                    <th>Rule ID</th>
                    <th>Name</th>
                    <th>Target</th>
                    <th>Condition</th>
                    <th>Severity</th>
                    <th className="text-right">Active</th>
                  </tr>
                </thead>
                <tbody>
                  {rules.map((r) => (
                    <tr key={r.rule_id}>
                      <td className="font-mono2 text-cyan-300">{r.rule_id}</td>
                      <td className="font-medium text-[12px]">{r.name}</td>
                      <td>
                        <Badge tone="purple">{r.target_type}</Badge>
                      </td>
                      <td className="font-mono2 text-[11px]">
                        {r.operator} <span className="text-amber-300">{r.threshold}</span>
                      </td>
                      <td>
                        <Badge tone={sevTone(r.severity)}>{r.severity}</Badge>
                      </td>
                      <td className="text-right">
                        <div className="flex justify-end">
                          <Toggle checked={r.active} onChange={(v) => toggleRule(r, v)} />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Glass>
      </div>

      {/* Alert feed */}
      <Glass className="p-0 overflow-hidden">
        <div className="p-5 pb-3 flex flex-wrap items-center justify-between gap-3">
          <SectionTitle icon={Bell} title="Deterministic Alert Feed" sub="lifecycle: NEW → ACKNOWLEDGED → RESOLVED" />
          <div className="flex gap-1.5">
            {FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => switchFilter(f)}
                className={cls(
                  'px-3 py-1.5 rounded-lg text-[10px] font-semibold uppercase tracking-wider transition-all border',
                  filter === f
                    ? 'bg-cyan-400/15 text-cyan-300 border-cyan-400/40'
                    : 'text-[var(--muted)] border-transparent hover:bg-[var(--panel-soft)]',
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
        {loading ? (
          <TableSkeleton rows={6} />
        ) : alerts.length === 0 ? (
          <Empty msg="No alerts in this lifecycle state." />
        ) : (
          <div className="overflow-x-auto">
            <table className="table-base w-full">
              <thead>
                <tr>
                  <th>Alert ID</th>
                  <th>Severity</th>
                  <th>Subject</th>
                  <th>Title / Description</th>
                  <th>Status</th>
                  <th>Action</th>
                  <th className="text-right">Age</th>
                </tr>
              </thead>
              <tbody>
                {alerts.map((a) => (
                  <tr key={a.alert_id}>
                    <td className="font-mono2 text-cyan-300">{a.alert_id}</td>
                    <td>
                      <Badge tone={sevTone(a.severity)}>
                        {a.severity === 'HIGH' && <ShieldAlert size={10} />}
                        {a.severity}
                      </Badge>
                    </td>
                    <td>
                      <Badge tone="slate">{a.subject_type}</Badge>
                      <div className="font-mono2 text-[10px] text-[var(--muted)] mt-1">{shortHash(a.subject_id, 8)}</div>
                    </td>
                    <td className="max-w-[340px]">
                      <div className="text-[12px] font-medium whitespace-normal">{a.title}</div>
                      <div className="text-[10px] text-[var(--muted)] whitespace-normal mt-0.5">{a.description}</div>
                    </td>
                    <td>
                      <Badge tone={statusTone(a.status)}>{a.status}</Badge>
                    </td>
                    <td>
                      <select
                        className="field !w-[150px] !py-1.5 !text-[11px]"
                        value={a.status}
                        onChange={(e) => setStatus(a, e.target.value)}
                      >
                        <option value="NEW">NEW</option>
                        <option value="ACKNOWLEDGED">ACKNOWLEDGED</option>
                        <option value="RESOLVED">RESOLVED</option>
                      </select>
                    </td>
                    <td className="text-right font-mono2 text-[10px] text-[var(--muted)]">{timeAgo(a.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Glass>

      {toast.node}
    </div>
  );
}

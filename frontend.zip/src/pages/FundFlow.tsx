import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Coins,
  Eye,
  FileJson,
  FileSpreadsheet,
  Play,
  Route,
  Share2,
  Timer,
} from 'lucide-react';
import { api, post } from '../lib/api';
import { Badge, Btn, Empty, ErrBox, Glass, Modal, PageHeader, SectionTitle, Skeleton, TableSkeleton, useToast } from '../components/ui';
import { cls, fmtNum, fmtSats, satsToBTC, shortHash, timeAgo } from '../lib/format';
import type { TaintExposed, TaintMethod, TaintRun } from '../lib/types';

const METHOD_TONE: Record<string, string> = { POISON: 'red', HAIRCUT: 'cyan', FIFO: 'purple', LIFO: 'amber' };

const PRESETS = [
  {
    label: 'Multi-Hop Chain',
    txid: '3f4b9d2a8c1e7f6a5b4c3d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b',
    vout: 0,
    sats: 500000000,
    max_hops: 6,
  },
  {
    label: 'Single-Hop Terminal',
    txid: 'c7a91e4f2b6d8a0c3e5f7b9d1a4c6e8f0b2d4a6c8e0f2a4b6c8d0e2f4a6c8e0f2a',
    vout: 1,
    sats: 75000000,
    max_hops: 1,
  },
];

interface TaintPayload {
  run: TaintRun;
  methods: TaintMethod[];
  exposed: TaintExposed[];
}

export default function FundFlow() {
  const [data, setData] = useState<TaintPayload | null>(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [inspect, setInspect] = useState<TaintExposed | null>(null);
  const [form, setForm] = useState({ txid: PRESETS[0].txid, vout: '0', sats: '500000000', max_hops: '6' });
  const toast = useToast();

  const load = async () => {
    try {
      setData(await api('/api/taint/results'));
    } catch (ex: any) {
      setErr(ex.message ?? 'Failed to load taint results');
    }
  };
  useEffect(() => {
    load();
  }, []);

  const run = async () => {
    if (!/^[0-9a-fA-F]{64}$/.test(form.txid)) return toast.push('TXID must be 64 hex characters', 'red');
    setBusy(true);
    try {
      const res = await post<TaintPayload>('/api/taint/run', {
        txid: form.txid,
        vout: Number(form.vout),
        sats: Number(form.sats),
        max_hops: Number(form.max_hops),
      });
      setData(res);
      toast.push(`Taint trace complete — ${res.exposed.length} exposed addresses resolved`);
    } catch (ex: any) {
      toast.push(ex.message ?? 'Trace failed', 'red');
    } finally {
      setBusy(false);
    }
  };

  const poison = data?.methods.find((m) => m.method === 'POISON');
  const maxHopsReached = data ? Math.max(...data.methods.map((m) => m.max_hops)) : 0;

  return (
    <div>
      <PageHeader
        title="Fund Flow Analysis"
        sub="Bitcoin UTXO taint forensics — 4-method propagation matrix with integer-satoshi conservation"
        right={
          <>
            <Btn kind="ghost" onClick={() => (window.location.href = '/api/taint/export?type=addresses_csv')}>
              <FileSpreadsheet size={13} /> Addresses CSV
            </Btn>
            <Btn kind="ghost" onClick={() => (window.location.href = '/api/taint/export?type=comparison_csv')}>
              <FileSpreadsheet size={13} /> Matrix CSV
            </Btn>
            <Btn kind="ghost" onClick={() => (window.location.href = '/api/taint/export?type=json')}>
              <FileJson size={13} /> JSON
            </Btn>
          </>
        }
      />

      {/* Guardrail banner */}
      <div className="glass rounded-2xl border-l-2 !border-l-amber-400 p-4 mb-5 flex gap-3">
        <AlertTriangle size={18} className="text-amber-400 shrink-0 mt-0.5" />
        <div>
          <div className="text-xs font-bold text-amber-300 tracking-wide uppercase">Forensic Guardrail — Legal Notice</div>
          <p className="text-[11px] text-[var(--muted)] mt-1 leading-relaxed max-w-4xl">
            Taint mathematics expresses <span className="text-amber-300 font-semibold">transactional association, not legal culpability</span>. Poison
            propagation overstates contagion (non-conserving upper bound); haircut, FIFO and LIFO conserve satoshi mass under different
            attribution policies. Exposure figures are probabilistic forensic leads and must be corroborated before any evidentiary use.
          </p>
        </div>
      </div>

      {/* Seed outpoint panel */}
      <Glass className="p-5 mb-5">
        <SectionTitle icon={Route} title="Seed Outpoint" sub="origin UTXO for DAG taint propagation" />
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-6 gap-3">
          <div className="xl:col-span-3">
            <label className="text-[10px] uppercase tracking-[0.14em] text-[var(--muted)] block mb-1.5">Seed TXID</label>
            <input className="field font-mono2" value={form.txid} onChange={(e) => setForm({ ...form, txid: e.target.value.trim() })} spellCheck={false} />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-[0.14em] text-[var(--muted)] block mb-1.5">Vout Index</label>
            <input className="field font-mono2" type="number" min={0} value={form.vout} onChange={(e) => setForm({ ...form, vout: e.target.value })} />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-[0.14em] text-[var(--muted)] block mb-1.5">Satoshis</label>
            <input className="field font-mono2" type="number" min={1} value={form.sats} onChange={(e) => setForm({ ...form, sats: e.target.value })} />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-[0.14em] text-[var(--muted)] block mb-1.5">Max Hops</label>
            <input className="field font-mono2" type="number" min={1} max={12} value={form.max_hops} onChange={(e) => setForm({ ...form, max_hops: e.target.value })} />
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-2.5">
          <Btn onClick={run} busy={busy}>
            <Play size={13} /> Run Taint Trace
          </Btn>
          {PRESETS.map((p) => (
            <Btn
              key={p.label}
              kind="ghost"
              onClick={() => setForm({ txid: p.txid, vout: String(p.vout), sats: String(p.sats), max_hops: String(p.max_hops) })}
            >
              {p.label}
            </Btn>
          ))}
          {data && (
            <span className="ml-auto text-[10px] font-mono2 text-[var(--muted)]">
              last run {timeAgo(data.run.created_at)} · seed {shortHash(data.run.txid, 8)}
            </span>
          )}
        </div>
      </Glass>

      {err && <ErrBox msg={err} />}

      {/* Telemetry cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-5">
        {!data ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28" />)
        ) : (
          <>
            <Glass hover className="p-5">
              <div className="flex items-center gap-2 text-[var(--muted)]"><Share2 size={14} className="text-cyan-400" /><span className="text-[10px] uppercase tracking-[0.14em]">Exposed Addresses</span></div>
              <div className="mt-2.5 text-2xl font-bold font-mono2 metric-glow">{fmtNum(data.exposed.length)}</div>
              <div className="text-[10px] text-[var(--muted)] font-mono2 mt-0.5">resolved via 4-method consensus</div>
            </Glass>
            <Glass hover className="p-5">
              <div className="flex items-center gap-2 text-[var(--muted)]"><AlertTriangle size={14} className="text-red-400" /><span className="text-[10px] uppercase tracking-[0.14em]">Tainted Outpoints</span></div>
              <div className="mt-2.5 text-2xl font-bold font-mono2 metric-glow">{fmtNum(poison?.tainted_outpoints)}</div>
              <div className="text-[10px] text-[var(--muted)] font-mono2 mt-0.5">poison upper bound (non-conserving)</div>
            </Glass>
            <Glass hover className="p-5">
              <div className="flex items-center gap-2 text-[var(--muted)]"><Timer size={14} className="text-purple-400" /><span className="text-[10px] uppercase tracking-[0.14em]">Max Hops Reached</span></div>
              <div className="mt-2.5 text-2xl font-bold font-mono2 metric-glow">{maxHopsReached}</div>
              <div className="text-[10px] text-[var(--muted)] font-mono2 mt-0.5">DAG traversal depth limit {data.run.max_hops}</div>
            </Glass>
            <Glass hover className="p-5">
              <div className="flex items-center gap-2 text-[var(--muted)]"><Coins size={14} className="text-amber-400" /><span className="text-[10px] uppercase tracking-[0.14em]">Total Seed Value</span></div>
              <div className="mt-2.5 text-2xl font-bold font-mono2 metric-glow">{satsToBTC(data.run.sats)} <span className="text-sm">BTC</span></div>
              <div className="text-[10px] text-[var(--muted)] font-mono2 mt-0.5">{fmtSats(data.run.sats)}</div>
            </Glass>
          </>
        )}
      </div>

      {/* 4-method propagation matrix */}
      <Glass className="p-0 overflow-hidden mb-5">
        <div className="p-5 pb-3">
          <SectionTitle icon={Share2} title="4-Method Propagation Matrix" sub="integer-satoshi conservation · largest remainder method for proportional dilution" />
        </div>
        {!data ? (
          <TableSkeleton rows={4} />
        ) : (
          <div className="overflow-x-auto">
            <table className="table-base w-full">
              <thead>
                <tr>
                  <th>Method</th>
                  <th>Type</th>
                  <th>Conserving</th>
                  <th className="text-right">Tainted Outpoints</th>
                  <th className="text-right">Tainted Satoshis</th>
                  <th className="text-right">Tainted BTC</th>
                  <th className="text-right">Max Hops</th>
                  <th className="text-right">Latency</th>
                </tr>
              </thead>
              <tbody>
                {data.methods.map((m) => (
                  <tr key={m.method}>
                    <td>
                      <Badge tone={METHOD_TONE[m.method]}>{m.method}</Badge>
                    </td>
                    <td className="text-[11px] text-[var(--muted)]">{m.mtype}</td>
                    <td>
                      <Badge tone={m.conserving ? 'emerald' : 'red'}>{m.conserving ? 'CONSERVING' : 'NON-CONSERVING'}</Badge>
                    </td>
                    <td className="text-right font-mono2">{fmtNum(m.tainted_outpoints)}</td>
                    <td className="text-right font-mono2">{fmtNum(m.tainted_sats)}</td>
                    <td className="text-right font-mono2 text-amber-300">{satsToBTC(m.tainted_sats)}</td>
                    <td className="text-right font-mono2">{m.max_hops}</td>
                    <td className="text-right font-mono2 text-cyan-300">{m.latency_ms.toFixed(1)} ms</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Glass>

      {/* Top exposed addresses */}
      <Glass className="p-0 overflow-hidden">
        <div className="p-5 pb-3">
          <SectionTitle icon={Eye} title="Top Exposed Addresses" sub="ranked by poison-model exposure · per-method satoshi attribution" />
        </div>
        {!data ? (
          <TableSkeleton rows={8} />
        ) : data.exposed.length === 0 ? (
          <Empty msg="No exposed addresses for this seed outpoint." />
        ) : (
          <div className="overflow-x-auto">
            <table className="table-base w-full">
              <thead>
                <tr>
                  <th>Address</th>
                  <th className="text-right">Hop</th>
                  <th className="text-right">Exposure</th>
                  <th className="text-right">Poison Sats</th>
                  <th className="text-right">Haircut Sats</th>
                  <th className="text-right">FIFO Sats</th>
                  <th className="text-right">LIFO Sats</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {data.exposed.map((a) => (
                  <tr key={a.id}>
                    <td className="font-mono2 text-cyan-300">{shortHash(a.address, 10)}</td>
                    <td className="text-right">
                      <Badge tone={a.hop_distance <= 1 ? 'red' : a.hop_distance <= 3 ? 'amber' : 'slate'}>H{a.hop_distance}</Badge>
                    </td>
                    <td className="text-right">
                      <span className="font-mono2">{a.exposure_pct.toFixed(1)}%</span>
                      <span className="block w-16 ml-auto h-1 rounded-full bg-[var(--panel-soft)] overflow-hidden mt-1">
                        <span className="block h-full bg-gradient-to-r from-red-400 to-amber-400" style={{ width: `${Math.min(100, a.exposure_pct)}%` }} />
                      </span>
                    </td>
                    <td className="text-right font-mono2 text-red-300">{fmtNum(a.poison_sats)}</td>
                    <td className="text-right font-mono2 text-cyan-300">{fmtNum(a.haircut_sats)}</td>
                    <td className="text-right font-mono2 text-purple-300">{fmtNum(a.fifo_sats)}</td>
                    <td className="text-right font-mono2 text-amber-300">{fmtNum(a.lifo_sats)}</td>
                    <td className="text-right">
                      <Btn kind="ghost" className="!px-2.5 !py-1.5" onClick={() => setInspect(a)}>
                        <Eye size={12} /> Inspect
                      </Btn>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Glass>

      {/* Inspect modal */}
      <Modal open={!!inspect} onClose={() => setInspect(null)} title={<span className="font-mono2 text-xs">{inspect?.address}</span>}>
        {inspect && (
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Badge tone="amber">HOP {inspect.hop_distance}</Badge>
              <Badge tone="red">{inspect.exposure_pct.toFixed(2)}% exposed</Badge>
            </div>
            <div className="space-y-3">
              {(['poison_sats', 'haircut_sats', 'fifo_sats', 'lifo_sats'] as const).map((k) => {
                const max = Math.max(inspect.poison_sats, 1);
                const v = inspect[k];
                const label = k.replace('_sats', '').toUpperCase();
                return (
                  <div key={k}>
                    <div className="flex justify-between text-[10px] uppercase tracking-wider text-[var(--muted)] mb-1">
                      <span>{label}</span>
                      <span className="font-mono2 text-[var(--text)]">{fmtNum(v)} sats · {satsToBTC(v)} BTC</span>
                    </div>
                    <div className="h-2 rounded-full bg-[var(--panel-soft)] overflow-hidden">
                      <div
                        className={cls(
                          'h-full rounded-full',
                          k === 'poison_sats' ? 'bg-red-400' : k === 'haircut_sats' ? 'bg-cyan-400' : k === 'fifo_sats' ? 'bg-purple-400' : 'bg-amber-400',
                        )}
                        style={{ width: `${Math.max(2, (v / max) * 100)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="mt-4 text-[10px] text-[var(--muted)] leading-relaxed">
              Per-method satoshi attribution for this address. Poison reflects unbounded contagion; conserving methods redistribute exactly the
              seed mass under their respective ordering policies.
            </p>
          </div>
        )}
      </Modal>

      {toast.node}
    </div>
  );
}

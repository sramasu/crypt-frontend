import { useState } from 'react';
import { fmtBTC, shortHash } from '../lib/format';
import { CAT_COLORS } from '../lib/palette';
import { Badge, Empty } from './ui';
import type { FlowRow } from '../lib/types';

/* ------------------------------------------------------------------ */
/*  Radial Wagon Wheel — center address + curved flow-share links      */
/* ------------------------------------------------------------------ */
export default function WagonWheel({
  center,
  destinations,
  onSelect,
}: {
  center: { address: string; category?: string; risk_index?: number; balance?: number } | null;
  destinations: FlowRow[];
  onSelect?: (addr: string) => void;
}) {
  const [hov, setHov] = useState<number | null>(null);
  const S = 640;
  const C = S / 2;
  const R = 216;
  const n = destinations.length;

  if (!center) return <Empty msg="Select an address to compute the radial flow wheel." />;
  if (!n) return <Empty msg="No counterparty flow intelligence indexed for this address." />;

  const pts = destinations.map((d, i) => {
    const a = -Math.PI / 2 + (i / n) * Math.PI * 2;
    return { x: C + R * Math.cos(a), y: C + R * Math.sin(a), a, d };
  });

  const ctrl = (x: number, y: number, i: number) => {
    const ux = (x - C) / R;
    const uy = (y - C) / R;
    const mx = (C + x) / 2;
    const my = (C + y) / 2;
    const k = (i % 2 === 0 ? 1 : -1) * 52;
    return { cx: mx + -uy * k, cy: my + ux * k };
  };

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${S} ${S}`} className="w-full h-auto select-none">
        <defs>
          <linearGradient id="wgGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#00E5FF" />
            <stop offset="1" stopColor="#a855f7" />
          </linearGradient>
          <radialGradient id="wgCore" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#00E5FF" stopOpacity="0.28" />
            <stop offset="1" stopColor="#00E5FF" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* orbit rings */}
        <circle cx={C} cy={C} r={R} fill="none" stroke="var(--border)" strokeDasharray="2 6" />
        <circle cx={C} cy={C} r={R * 0.62} fill="none" stroke="var(--border)" strokeDasharray="2 6" opacity="0.6" />

        {/* curved flow links */}
        {pts.map((p, i) => {
          const { cx, cy } = ctrl(p.x, p.y, i);
          const col = CAT_COLORS[p.d.category ?? 'Unknown'] ?? CAT_COLORS.Unknown;
          return (
            <g key={`l-${i}`}>
              <path
                d={`M ${C} ${C} Q ${cx} ${cy} ${p.x} ${p.y}`}
                fill="none"
                stroke={col}
                strokeOpacity={hov === null || hov === i ? (hov === i ? 0.95 : 0.4) : 0.08}
                strokeWidth={1.4 + p.d.pct / 4.5}
                strokeLinecap="round"
                className="flow-anim"
                style={{ transition: 'stroke-opacity .2s' }}
              />
              {/* pct label at curve midpoint */}
              <text
                x={0.25 * C + 0.5 * cx + 0.25 * p.x}
                y={0.25 * C + 0.5 * cy + 0.25 * p.y - 4}
                textAnchor="middle"
                fontSize="11"
                fontWeight="700"
                fontFamily="'JetBrains Mono',monospace"
                fill={col}
                opacity={hov === null || hov === i ? 1 : 0.15}
                style={{ transition: 'opacity .2s' }}
              >
                {p.d.pct.toFixed(1)}%
              </text>
            </g>
          );
        })}

        {/* center node */}
        <circle cx={C} cy={C} r={74} fill="url(#wgCore)" />
        <circle cx={C} cy={C} r={46} fill="var(--panel-solid)" stroke="url(#wgGrad)" strokeWidth="2" />
        <text x={C} y={C - 6} textAnchor="middle" fontSize="8" letterSpacing="2" fill="var(--muted)">
          CENTER
        </text>
        <text x={C} y={C + 10} textAnchor="middle" fontSize="10.5" fontWeight="700" fontFamily="'JetBrains Mono',monospace" fill="var(--text)">
          {shortHash(center.address, 6)}
        </text>

        {/* destination nodes */}
        {pts.map((p, i) => {
          const col = CAT_COLORS[p.d.category ?? 'Unknown'] ?? CAT_COLORS.Unknown;
          return (
            <g
              key={`n-${i}`}
              onMouseEnter={() => setHov(i)}
              onMouseLeave={() => setHov(null)}
              onClick={() => onSelect?.(p.d.counterparty)}
              style={{ cursor: onSelect ? 'pointer' : 'default' }}
            >
              <circle cx={p.x} cy={p.y} r={hov === i ? 28 : 24} fill="var(--panel-solid)" stroke={col} strokeWidth={hov === i ? 2.4 : 1.4} style={{ transition: 'all .2s' }} />
              <circle cx={p.x} cy={p.y} r={5.5} fill={col} />
              <text
                x={p.x}
                y={p.y + (p.y >= C ? 42 : -34)}
                textAnchor="middle"
                fontSize="10"
                fontFamily="'JetBrains Mono',monospace"
                fill="var(--text)"
                fontWeight="600"
              >
                {shortHash(p.d.counterparty, 5)}
              </text>
              <text x={p.x} y={p.y + (p.y >= C ? 55 : -22)} textAnchor="middle" fontSize="8.5" fill="var(--muted)">
                {p.d.label || p.d.category || 'unknown'}
              </text>
            </g>
          );
        })}
      </svg>

      {/* floating tooltip */}
      {hov !== null && (
        <div
          className="absolute z-20 pointer-events-none glass rounded-xl p-3.5 w-60 shadow-2xl"
          style={{
            left: `${Math.min(72, Math.max(4, (pts[hov].x / S) * 100 - 12))}%`,
            top: `${Math.min(72, Math.max(4, (pts[hov].y / S) * 100 - 10))}%`,
          }}
        >
          <div className="flex items-center justify-between mb-1.5">
            <Badge tone={(pts[hov].d.risk ?? 0) >= 0.8 ? 'red' : (pts[hov].d.risk ?? 0) >= 0.65 ? 'amber' : 'cyan'}>
              {pts[hov].d.category ?? 'Unknown'}
            </Badge>
            <span className="font-mono2 text-[10px] text-cyan-300">{pts[hov].d.pct.toFixed(1)}%</span>
          </div>
          <div className="font-mono2 text-[10px] break-all text-[var(--text)] mb-2">{pts[hov].d.counterparty}</div>
          <div className="flex justify-between text-[10px] text-[var(--muted)]">
            <span>
              Flow <span className="font-mono2 text-[var(--text)]">{fmtBTC(pts[hov].d.volume, 3)}</span>
            </span>
            <span className="uppercase">{pts[hov].d.direction === 'in' ? '⬅ inbound' : 'outbound ⮕'}</span>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  2-Hop local ego-net visualiser (Pipeline Stage 4)                  */
/* ------------------------------------------------------------------ */
export function EgoNet({
  center,
  ring1,
  ring2,
}: {
  center: string;
  ring1: { address: string; label?: string; category?: string }[];
  ring2: Record<string, { address: string; label?: string }[]>;
}) {
  const S = 700;
  const C = S / 2;
  const R1 = 172;
  const R2 = 268;
  const n1 = ring1.length;

  if (!n1) return <Empty msg="No 1-hop neighbours indexed for this address." />;

  const p1 = ring1.map((r, i) => {
    const a = -Math.PI / 2 + (i / n1) * Math.PI * 2;
    return { ...r, x: C + R1 * Math.cos(a), y: C + R1 * Math.sin(a), a };
  });

  const p2: { parent: number; address: string; x: number; y: number }[] = [];
  p1.forEach((p, i) => {
    const kids = (ring2[p.address] ?? []).slice(0, 3);
    kids.forEach((k, j) => {
      const a = p.a + (j - (kids.length - 1) / 2) * 0.3;
      p2.push({ parent: i, address: k.address, x: C + R2 * Math.cos(a), y: C + R2 * Math.sin(a) });
    });
  });

  return (
    <svg viewBox={`0 0 ${S} ${S}`} className="w-full h-auto select-none">
      <circle cx={C} cy={C} r={R1} fill="none" stroke="var(--border)" strokeDasharray="2 6" />
      <circle cx={C} cy={C} r={R2} fill="none" stroke="var(--border)" strokeDasharray="2 6" opacity="0.5" />

      {p2.map((q, i) => (
        <line key={`e2-${i}`} x1={p1[q.parent].x} y1={p1[q.parent].y} x2={q.x} y2={q.y} stroke="var(--border)" strokeWidth="1" />
      ))}
      {p1.map((p, i) => {
        const col = CAT_COLORS[p.category ?? 'Unknown'] ?? CAT_COLORS.Unknown;
        return <line key={`e1-${i}`} x1={C} y1={C} x2={p.x} y2={p.y} stroke={col} strokeOpacity="0.5" strokeWidth="1.6" className="flow-anim" />;
      })}

      {p2.map((q, i) => (
        <g key={`n2-${i}`}>
          <circle cx={q.x} cy={q.y} r={10} fill="var(--panel-solid)" stroke="var(--border)" />
          <circle cx={q.x} cy={q.y} r={3} fill="var(--muted)" />
          <text x={q.x} y={q.y + 22} textAnchor="middle" fontSize="8" fontFamily="'JetBrains Mono',monospace" fill="var(--muted)">
            {shortHash(q.address, 4)}
          </text>
        </g>
      ))}

      {p1.map((p, i) => {
        const col = CAT_COLORS[p.category ?? 'Unknown'] ?? CAT_COLORS.Unknown;
        return (
          <g key={`n1-${i}`}>
            <circle cx={p.x} cy={p.y} r={19} fill="var(--panel-solid)" stroke={col} strokeWidth="1.6" />
            <circle cx={p.x} cy={p.y} r={4.5} fill={col} />
            <text x={p.x} y={p.y - 27} textAnchor="middle" fontSize="9" fontFamily="'JetBrains Mono',monospace" fill="var(--text)" fontWeight="600">
              {shortHash(p.address, 5)}
            </text>
          </g>
        );
      })}

      <circle cx={C} cy={C} r={38} fill="var(--panel-solid)" stroke="url(#wgGrad)" strokeWidth="2" />
      <text x={C} y={C - 3} textAnchor="middle" fontSize="7" letterSpacing="2" fill="var(--muted)">
        EGO
      </text>
      <text x={C} y={C + 11} textAnchor="middle" fontSize="9.5" fontWeight="700" fontFamily="'JetBrains Mono',monospace" fill="var(--text)">
        {shortHash(center, 5)}
      </text>
    </svg>
  );
}

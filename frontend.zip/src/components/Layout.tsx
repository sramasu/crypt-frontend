import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Fingerprint,
  LayoutDashboard,
  Menu,
  Moon,
  ScanSearch,
  ShieldAlert,
  Sun,
  Waypoints,
  X,
} from 'lucide-react';
import { useTheme } from '../lib/theme';
import { cls } from '../lib/format';

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, code: '01' },
  { to: '/explorer', label: 'Wallet Explorer', icon: ScanSearch, code: '02' },
  { to: '/fund-flow', label: 'Fund Flow Analysis', icon: Waypoints, code: '03' },
  { to: '/monitoring', label: 'Monitoring', icon: ShieldAlert, code: '04' },
];

const TITLES: Record<string, string> = {
  '/dashboard': 'EXECUTIVE TELEMETRY',
  '/explorer': 'WALLET INTELLIGENCE',
  '/fund-flow': 'UTXO TAINT FORENSICS',
  '/monitoring': 'SURVEILLANCE & RULE ENGINE',
};

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-3 px-5 pt-6 pb-5 border-b border-[var(--border)]">
        <span className="p-2.5 rounded-xl bg-gradient-to-br from-cyan-500/25 to-purple-500/25 border border-cyan-400/30 shadow-[0_0_18px_-4px_rgba(0,229,255,0.6)]">
          <Fingerprint size={20} className="text-cyan-400" />
        </span>
        <div>
          <div className="text-sm font-extrabold tracking-[0.14em] text-aurora">CRYPTO ANALYTICS</div>
          <div className="text-[9px] uppercase tracking-[0.18em] text-[var(--muted)]">Entity Resolution OS</div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV.map((n) => (
          <NavLink
            key={n.to}
            to={n.to}
            onClick={onNavigate}
            className={({ isActive }) =>
              cls(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] font-medium transition-all group',
                isActive
                  ? 'bg-cyan-400/10 text-cyan-300 border border-cyan-400/25 shadow-[inset_0_0_18px_-8px_rgba(0,229,255,0.5)]'
                  : 'text-[var(--muted)] hover:text-[var(--text)] hover:bg-[var(--panel-soft)] border border-transparent',
              )
            }
          >
            <n.icon size={16} className="shrink-0" />
            <span className="flex-1">{n.label}</span>
            <span className="font-mono2 text-[9px] opacity-40 group-hover:opacity-80">{n.code}</span>
          </NavLink>
        ))}
      </nav>

      <div className="px-4 pb-5">
        <div className="glass rounded-xl p-3.5">
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.14em] text-[var(--muted)]">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 live-dot" />
            Forensic Engine
          </div>
          <div className="mt-1.5 text-[11px] font-mono2 text-emerald-400">SUPABASE // POSTGRES</div>
          <div className="text-[10px] text-[var(--muted)] mt-0.5 font-mono2">CA-CORE v2.4.1</div>
        </div>
      </div>
    </div>
  );
}

export default function Layout() {
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);
  const [now, setNow] = useState(new Date());
  const location = useLocation();

  useEffect(() => {
    const i = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(i);
  }, []);

  const utc = now.toISOString().slice(11, 19);
  const section = TITLES[location.pathname] ?? 'FORENSIC INTELLIGENCE';

  return (
    <div className="min-h-screen">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex fixed inset-y-0 left-0 w-64 flex-col glass border-y-0 border-l-0 rounded-none z-40">
        <SidebarContent />
      </aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {open && (
          <motion.div className="fixed inset-0 z-[80] lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setOpen(false)} />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              className="absolute inset-y-0 left-0 w-64 glass rounded-none border-y-0 border-l-0"
            >
              <button
                onClick={() => setOpen(false)}
                className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-[var(--panel-soft)] text-[var(--muted)]"
              >
                <X size={16} />
              </button>
              <SidebarContent onNavigate={() => setOpen(false)} />
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="lg:pl-64 flex flex-col min-h-screen">
        {/* Top header */}
        <header className="sticky top-0 z-30 glass rounded-none border-x-0 border-t-0 px-4 sm:px-6 py-3 flex items-center gap-3">
          <button
            className="lg:hidden p-2 rounded-lg hover:bg-[var(--panel-soft)] text-[var(--muted)]"
            onClick={() => setOpen(true)}
            aria-label="open navigation"
          >
            <Menu size={18} />
          </button>
          <div className="flex items-center gap-2 text-[10px] font-mono2 tracking-[0.18em] text-[var(--muted)] uppercase">
            <span className="hidden sm:inline text-cyan-400">CRYPTO ANALYTICS</span>
            <span className="hidden sm:inline">//</span>
            <span>{section}</span>
          </div>
          <div className="flex-1" />
          <div className="hidden md:flex items-center gap-2 text-[10px] font-mono2 text-[var(--muted)]">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 live-dot" />
            <span className="text-emerald-400 tracking-widest">LIVE</span>
            <span>{utc} UTC</span>
          </div>
          <button
            onClick={toggle}
            className="p-2 rounded-xl glass hover:border-cyan-400/40 transition-all text-[var(--muted)] hover:text-cyan-400"
            aria-label="toggle theme"
            title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
          </button>
        </header>

        <main className="flex-1 px-4 sm:px-6 py-6 max-w-[1600px] w-full mx-auto">
          <Outlet />
        </main>

        <footer className="px-6 py-4 text-center text-[10px] font-mono2 text-[var(--muted)] tracking-widest uppercase opacity-60">
          Crypto Analytics Forensic Intelligence — Entity Resolution · Sub-Graph GNN · UTXO Taint Analysis
        </footer>
      </div>
    </div>
  );
}

import { useState } from 'react';
import type { ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangle, Inbox, Loader2, X } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { cls } from '../lib/format';

/* ---------------- Glass panel ---------------- */
export const Glass = ({ className, children, hover }: { className?: string; children: ReactNode; hover?: boolean }) => (
  <div className={cls('glass rounded-2xl', hover && 'glass-hover', className)}>{children}</div>
);

/* ---------------- Badge ---------------- */
export const Badge = ({ tone = 'slate', children, className }: { tone?: string; children: ReactNode; className?: string }) => (
  <span className={cls('badge', `badge-${tone}`, className)}>{children}</span>
);

/* ---------------- Section title ---------------- */
export const SectionTitle = ({ icon: Icon, title, sub, right }: { icon: LucideIcon; title: string; sub?: string; right?: ReactNode }) => (
  <div className="flex items-start justify-between gap-3 mb-4">
    <div className="flex items-center gap-2.5">
      <span className="p-1.5 rounded-lg bg-cyan-400/10 border border-cyan-400/25">
        <Icon size={15} className="text-cyan-400" />
      </span>
      <div>
        <h3 className="text-sm font-semibold tracking-wide">{title}</h3>
        {sub && <p className="text-[11px] text-[var(--muted)] mt-0.5">{sub}</p>}
      </div>
    </div>
    {right}
  </div>
);

/* ---------------- Page header ---------------- */
export const PageHeader = ({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) => (
  <div className="flex flex-wrap items-end justify-between gap-3 mb-6">
    <div>
      <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-aurora inline-block">{title}</h1>
      {sub && <p className="text-xs text-[var(--muted)] mt-1 max-w-2xl">{sub}</p>}
    </div>
    {right && <div className="flex items-center gap-2">{right}</div>}
  </div>
);

/* ---------------- KPI stat card ---------------- */
export const Stat = ({ icon: Icon, label, value, sub, tone = 'cyan' }: { icon: LucideIcon; label: string; value: ReactNode; sub?: ReactNode; tone?: string }) => {
  const map: Record<string, string> = {
    cyan: 'text-cyan-400 bg-cyan-400/10 border-cyan-400/25',
    emerald: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/25',
    amber: 'text-amber-400 bg-amber-400/10 border-amber-400/25',
    red: 'text-red-400 bg-red-400/10 border-red-400/25',
    purple: 'text-purple-400 bg-purple-400/10 border-purple-400/25',
  };
  const [tilt, setTilt] = useState('');
  return (
    <div
      style={{ transform: tilt, transition: 'transform 0.18s ease-out', transformStyle: 'preserve-3d' }}
      onMouseMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - 0.5;
        const py = (e.clientY - r.top) / r.height - 0.5;
        setTilt(`perspective(720px) rotateX(${(-py * 8).toFixed(2)}deg) rotateY(${(px * 10).toFixed(2)}deg) translateY(-2px)`);
      }}
      onMouseLeave={() => setTilt('')}
    >
      <Glass hover className="p-5 relative overflow-hidden h-full">
        <div className="absolute -top-8 -right-8 w-28 h-28 rounded-full bg-cyan-400/5 blur-2xl pointer-events-none" />
        <div className="flex items-center justify-between">
          <span className={cls('p-2 rounded-xl border', map[tone] ?? map.cyan)}>
            <Icon size={17} />
          </span>
          {sub}
        </div>
        <div className="mt-4 text-2xl font-bold font-mono2 metric-glow">{value}</div>
        <div className="mt-1 text-[11px] uppercase tracking-[0.14em] text-[var(--muted)]">{label}</div>
      </Glass>
    </div>
  );
};

/* ---------------- Skeleton ---------------- */
export const Skeleton = ({ className }: { className?: string }) => <div className={cls('skeleton', className)} />;

export const TableSkeleton = ({ rows = 6 }: { rows?: number }) => (
  <div className="space-y-2 p-4">
    {Array.from({ length: rows }).map((_, i) => (
      <Skeleton key={i} className="h-8 w-full" />
    ))}
  </div>
);

/* ---------------- Spinner / states ---------------- */
export const Spinner = ({ className }: { className?: string }) => <Loader2 size={18} className={cls('animate-spin text-cyan-400', className)} />;

export const Empty = ({ msg = 'No intelligence records found.' }: { msg?: string }) => (
  <div className="flex flex-col items-center justify-center py-10 text-center">
    <Inbox size={22} className="text-[var(--muted)] mb-2" />
    <p className="text-xs text-[var(--muted)]">{msg}</p>
  </div>
);

export const ErrBox = ({ msg }: { msg: string }) => (
  <div className="flex items-center gap-2 p-3 rounded-xl border border-red-400/30 bg-red-400/10 text-red-300 text-xs">
    <AlertTriangle size={14} /> {msg}
  </div>
);

/* ---------------- Toggle switch ---------------- */
export const Toggle = ({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) => (
  <button
    type="button"
    onClick={() => onChange(!checked)}
    className={cls('w-10 h-[22px] rounded-full relative transition-colors duration-200 shrink-0', checked ? 'bg-cyan-500/80' : 'bg-slate-500/40')}
    aria-label="toggle"
  >
    <span
      className={cls(
        'absolute top-[3px] w-4 h-4 rounded-full bg-white transition-all duration-200 shadow',
        checked ? 'left-[22px]' : 'left-[3px]',
      )}
    />
  </button>
);

/* ---------------- Buttons ---------------- */
export const Btn = ({
  children,
  onClick,
  kind = 'primary',
  className,
  disabled,
  busy,
  type = 'button',
}: {
  children: ReactNode;
  onClick?: () => void;
  kind?: 'primary' | 'ghost' | 'danger';
  className?: string;
  disabled?: boolean;
  busy?: boolean;
  type?: 'button' | 'submit';
}) => {
  const styles =
    kind === 'primary'
      ? 'bg-gradient-to-r from-cyan-500 to-sky-600 text-white shadow-[0_0_20px_-6px_rgba(0,229,255,0.7)] hover:brightness-110'
      : kind === 'danger'
        ? 'bg-red-500/15 text-red-300 border border-red-400/40 hover:bg-red-500/25'
        : 'glass text-[var(--text)] hover:border-cyan-400/40';
  return (
    <button
      type={type}
      disabled={disabled || busy}
      onClick={onClick}
      className={cls(
        'inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-[11px] font-semibold tracking-wider uppercase transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none',
        styles,
        className,
      )}
    >
      {busy && <Loader2 size={13} className="animate-spin" />}
      {children}
    </button>
  );
};

/* ---------------- Modal ---------------- */
export const Modal = ({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  children: ReactNode;
  wide?: boolean;
}) => (
  <AnimatePresence>
    {open && (
      <motion.div
        className="fixed inset-0 z-[90] flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <div className="absolute inset-0 bg-black/65 backdrop-blur-sm" onClick={onClose} />
        <motion.div
          initial={{ scale: 0.94, y: 18, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          transition={{ type: 'spring', damping: 26, stiffness: 320 }}
          className={cls('glass rounded-2xl relative w-full max-h-[85vh] overflow-y-auto shadow-2xl', wide ? 'max-w-3xl' : 'max-w-lg')}
        >
          <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--border)] sticky top-0 bg-[var(--panel-solid)]/80 backdrop-blur-md z-10">
            <div className="text-sm font-semibold">{title}</div>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-[var(--panel-soft)] text-[var(--muted)] hover:text-[var(--text)] transition-colors">
              <X size={15} />
            </button>
          </div>
          <div className="p-5">{children}</div>
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

/* ---------------- Confidence pill ---------------- */
export const ConfPill = ({ value }: { value: number }) => {
  const tone = value >= 95 ? 'emerald' : value >= 85 ? 'cyan' : 'amber';
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="w-14 h-1.5 rounded-full bg-[var(--panel-soft)] overflow-hidden inline-block">
        <span
          className={cls('block h-full rounded-full', tone === 'emerald' ? 'bg-emerald-400' : tone === 'cyan' ? 'bg-cyan-400' : 'bg-amber-400')}
          style={{ width: `${Math.min(100, value)}%` }}
        />
      </span>
      <span className="font-mono2 text-[11px]">{value.toFixed(1)}%</span>
    </span>
  );
};

/* ---------------- Risk gauge ---------------- */
export const RiskGauge = ({ value }: { value: number }) => {
  const pct = Math.round(value * 100);
  const color = value >= 0.8 ? '#ef4444' : value >= 0.65 ? '#f59e0b' : value >= 0.4 ? '#a855f7' : '#10b981';
  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 120 70" className="w-24">
        <path d="M10 62 A 50 50 0 0 1 110 62" fill="none" stroke="var(--panel-soft)" strokeWidth="10" strokeLinecap="round" />
        <path
          d="M10 62 A 50 50 0 0 1 110 62"
          fill="none"
          stroke={color}
          strokeWidth="10"
          strokeLinecap="round"
          pathLength={100}
          strokeDasharray={`${Math.max(2, pct)} 100`}
          style={{ filter: `drop-shadow(0 0 6px ${color}88)` }}
        />
        <text x="60" y="50" textAnchor="middle" fill="var(--text)" fontSize="19" fontWeight="700" fontFamily="'JetBrains Mono',monospace">
          {pct}
        </text>
        <text x="60" y="64" textAnchor="middle" fill="var(--muted)" fontSize="7" letterSpacing="1.5">
          RISK / 100
        </text>
      </svg>
    </div>
  );
};

/* ---------------- Toasts ---------------- */
export function useToast() {
  const [items, setItems] = useState<{ id: number; msg: string; tone: string }[]>([]);
  const push = (msg: string, tone = 'cyan') => {
    const id = Math.random();
    setItems((xs) => [...xs, { id, msg, tone }]);
    setTimeout(() => setItems((xs) => xs.filter((x) => x.id !== id)), 4200);
  };
  const node = (
    <div className="fixed bottom-6 right-6 z-[120] flex flex-col gap-2 items-end pointer-events-none">
      <AnimatePresence>
        {items.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, x: 48 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 48 }}
            className="glass rounded-xl px-4 py-3 text-xs flex items-center gap-2.5 shadow-2xl max-w-sm"
          >
            <span
              className={cls(
                'w-2 h-2 rounded-full shrink-0',
                t.tone === 'red' ? 'bg-red-400' : t.tone === 'amber' ? 'bg-amber-400' : t.tone === 'emerald' ? 'bg-emerald-400' : 'bg-cyan-400',
              )}
            />
            <span>{t.msg}</span>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
  return { push, node };
}

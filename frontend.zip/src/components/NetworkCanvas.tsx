import { useEffect, useRef, useState } from 'react';
import { Maximize2, Minus, Plus, Zap, ZapOff } from 'lucide-react';
import { useTheme } from '../lib/theme';
import { CAT_COLORS, palette } from '../lib/palette';
import { cls, fmtBTC, fmtNum, shortHash } from '../lib/format';
import { Badge } from './ui';
import type { GEdge, GNode } from '../lib/types';

interface SimNode extends GNode {
  x: number;
  y: number;
  vx: number;
  vy: number;
}

const nodeRadius = (n: GNode) => 6 + Math.min(8, Math.log10(1 + (n.volume || 1)) * 2);

export default function NetworkCanvas({
  nodes,
  edges,
  onSelect,
}: {
  nodes: GNode[];
  edges: GEdge[];
  onSelect?: (id: string) => void;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [physics, setPhysics] = useState(true);
  const physicsRef = useRef(true);
  const [hover, setHover] = useState<{ n: SimNode; x: number; y: number } | null>(null);
  const { theme } = useTheme();
  const pal = palette(theme);
  const sim = useRef({
    nodes: [] as SimNode[],
    edges: [] as { s: number; t: number; value: number }[],
    t: { x: 0, y: 0, k: 1 },
  });
  const dragNode = useRef(-1);
  const pan = useRef<{ sx: number; sy: number; ox: number; oy: number } | null>(null);
  const moved = useRef(0);

  useEffect(() => {
    physicsRef.current = physics;
  }, [physics]);

  /* (Re)initialise simulation state whenever the dataset changes */
  useEffect(() => {
    const N = Math.max(1, nodes.length);
    const ns: SimNode[] = nodes.map((n, i) => ({
      ...n,
      x: 300 + 200 * Math.cos((i / N) * Math.PI * 2),
      y: 230 + 165 * Math.sin((i / N) * Math.PI * 2),
      vx: 0,
      vy: 0,
    }));
    const idx = new Map(ns.map((n, i) => [n.id, i] as const));
    const es = edges
      .map((e) => ({ s: idx.get(e.source) ?? -1, t: idx.get(e.target) ?? -1, value: e.value }))
      .filter((e) => e.s >= 0 && e.t >= 0);
    sim.current.nodes = ns;
    sim.current.edges = es;
  }, [nodes, edges]);

  const zoom = (f: number) => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const { t } = sim.current;
    const r = wrap.getBoundingClientRect();
    const cx = r.width / 2;
    const cy = r.height / 2;
    const k2 = Math.min(3, Math.max(0.35, t.k * f));
    t.x = cx - ((cx - t.x) / t.k) * k2;
    t.y = cy - ((cy - t.y) / t.k) * k2;
    t.k = k2;
  };

  /* Render + physics loop, sized to container, theme-aware */
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let raf = 0;
    const dpr = window.devicePixelRatio || 1;

    const resize = () => {
      const r = wrap.getBoundingClientRect();
      canvas.width = r.width * dpr;
      canvas.height = r.height * dpr;
      canvas.style.width = `${r.width}px`;
      canvas.style.height = `${r.height}px`;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const wheelHandler = (e: WheelEvent) => {
      e.preventDefault();
      zoom(e.deltaY < 0 ? 1.12 : 0.89);
    };
    canvas.addEventListener('wheel', wheelHandler, { passive: false });

    const step = () => {
      const { nodes: ns, edges: es, t } = sim.current;
      const W = canvas.width / dpr;
      const H = canvas.height / dpr;

      if (physicsRef.current && ns.length) {
        for (let i = 0; i < ns.length; i++) {
          const a = ns[i];
          for (let j = i + 1; j < ns.length; j++) {
            const b = ns[j];
            let dx = a.x - b.x;
            let dy = a.y - b.y;
            let d2 = dx * dx + dy * dy;
            if (d2 < 4) {
              dx = Math.random() - 0.5;
              dy = Math.random() - 0.5;
              d2 = 4;
            }
            const d = Math.sqrt(d2);
            const f = Math.min(3.2, 2400 / d2);
            a.vx += (dx / d) * f;
            a.vy += (dy / d) * f;
            b.vx -= (dx / d) * f;
            b.vy -= (dy / d) * f;
          }
          a.vx += (W / 2 - a.x) * 0.012;
          a.vy += (H / 2 - a.y) * 0.012;
        }
        for (const e of es) {
          const a = ns[e.s];
          const b = ns[e.t];
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const d = Math.max(1, Math.hypot(dx, dy));
          const f = (d - 118) * 0.02;
          a.vx += (dx / d) * f;
          a.vy += (dy / d) * f;
          b.vx -= (dx / d) * f;
          b.vy -= (dy / d) * f;
        }
        ns.forEach((n, i) => {
          if (i === dragNode.current) {
            n.vx = 0;
            n.vy = 0;
            return;
          }
          n.vx *= 0.82;
          n.vy *= 0.82;
          n.x += n.vx;
          n.y += n.vy;
        });
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, W, H);
      ctx.translate(t.x, t.y);
      ctx.scale(t.k, t.k);

      for (const e of es) {
        const a = ns[e.s];
        const b = ns[e.t];
        ctx.strokeStyle = pal.edge;
        ctx.lineWidth = 0.6 + Math.min(3, e.value / 14);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }

      ctx.font = '9px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      for (const n of ns) {
        const r = nodeRadius(n);
        const c = CAT_COLORS[n.category] || CAT_COLORS.Unknown;
        ctx.beginPath();
        ctx.arc(n.x, n.y, r + 6, 0, Math.PI * 2);
        ctx.fillStyle = `${c}22`;
        ctx.fill();
        ctx.beginPath();
        ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
        ctx.globalAlpha = 0.92;
        ctx.fillStyle = c;
        ctx.fill();
        ctx.globalAlpha = 1;
        ctx.lineWidth = n.risk >= 0.8 ? 2 : 1.2;
        ctx.strokeStyle = n.risk >= 0.8 ? '#ef4444' : c;
        ctx.stroke();
        ctx.fillStyle = pal.text;
        ctx.fillText(shortHash(n.id, 5), n.x, n.y + r + 13);
      }
      ctx.restore();
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener('wheel', wheelHandler);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pal]);

  const pos = (e: React.MouseEvent) => {
    const r = wrapRef.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  const toWorld = (px: number, py: number) => {
    const { t } = sim.current;
    return { x: (px - t.x) / t.k, y: (py - t.y) / t.k };
  };
  const nodeAt = (px: number, py: number) => {
    const w = toWorld(px, py);
    const ns = sim.current.nodes;
    for (let i = ns.length - 1; i >= 0; i--) {
      const n = ns[i];
      if (Math.hypot(n.x - w.x, n.y - w.y) <= nodeRadius(n) + 7) return i;
    }
    return -1;
  };

  const onMouseDown = (e: React.MouseEvent) => {
    const p = pos(e);
    moved.current = 0;
    const i = nodeAt(p.x, p.y);
    if (i >= 0) dragNode.current = i;
    else {
      const { t } = sim.current;
      pan.current = { sx: p.x, sy: p.y, ox: t.x, oy: t.y };
    }
  };
  const onMouseMove = (e: React.MouseEvent) => {
    const p = pos(e);
    if (dragNode.current >= 0) {
      const w = toWorld(p.x, p.y);
      const n = sim.current.nodes[dragNode.current];
      n.x = w.x;
      n.y = w.y;
      moved.current += 1;
      return;
    }
    if (pan.current) {
      const { t } = sim.current;
      t.x = pan.current.ox + (p.x - pan.current.sx);
      t.y = pan.current.oy + (p.y - pan.current.sy);
      moved.current += 1;
      return;
    }
    const i = nodeAt(p.x, p.y);
    setHover(i >= 0 ? { n: sim.current.nodes[i], x: p.x, y: p.y } : null);
  };
  const onMouseUp = () => {
    if (dragNode.current >= 0 && moved.current < 3 && onSelect) onSelect(sim.current.nodes[dragNode.current].id);
    dragNode.current = -1;
    pan.current = null;
  };
  const onLeave = () => {
    setHover(null);
    dragNode.current = -1;
    pan.current = null;
  };
  const reset = () => {
    sim.current.t = { x: 0, y: 0, k: 1 };
  };

  const cats = Array.from(new Set(nodes.map((n) => n.category))).slice(0, 7);

  return (
    <div
      ref={wrapRef}
      className="relative w-full h-[440px] rounded-xl overflow-hidden cursor-grab active:cursor-grabbing border border-[var(--border)]"
      style={{ background: 'radial-gradient(620px 320px at 50% 40%, rgba(0,229,255,0.05), transparent 72%)' }}
    >
      <canvas
        ref={canvasRef}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={onLeave}
        className="absolute inset-0"
      />

      {/* Controls */}
      <div className="absolute top-3 right-3 flex flex-col gap-1.5 z-10">
        <button className="glass rounded-lg p-2 text-[var(--muted)] hover:text-cyan-400 transition-colors" onClick={() => zoom(1.25)} title="Zoom in">
          <Plus size={14} />
        </button>
        <button className="glass rounded-lg p-2 text-[var(--muted)] hover:text-cyan-400 transition-colors" onClick={() => zoom(0.8)} title="Zoom out">
          <Minus size={14} />
        </button>
        <button className="glass rounded-lg p-2 text-[var(--muted)] hover:text-cyan-400 transition-colors" onClick={reset} title="Reset view">
          <Maximize2 size={14} />
        </button>
        <button
          className={cls('glass rounded-lg p-2 transition-colors', physics ? 'text-cyan-400 border-cyan-400/40' : 'text-[var(--muted)]')}
          onClick={() => setPhysics((p) => !p)}
          title={physics ? 'Freeze physics' : 'Resume physics'}
        >
          {physics ? <Zap size={14} /> : <ZapOff size={14} />}
        </button>
      </div>

      {/* Legend */}
      <div className="absolute bottom-3 left-3 z-10 glass rounded-xl px-3 py-2 flex flex-wrap gap-x-3 gap-y-1 max-w-[70%]">
        {cats.map((c) => (
          <span key={c} className="flex items-center gap-1.5 text-[9px] uppercase tracking-wider text-[var(--muted)]">
            <span className="w-2 h-2 rounded-full" style={{ background: CAT_COLORS[c] ?? CAT_COLORS.Unknown }} />
            {c}
          </span>
        ))}
      </div>

      {/* Ultra floating hover card */}
      {hover && (
        <div
          className="absolute z-20 pointer-events-none glass rounded-xl p-3.5 w-64 shadow-2xl"
          style={{
            left: Math.min(hover.x + 16, Math.max(8, (wrapRef.current?.clientWidth ?? 420) - 270)),
            top: Math.max(8, Math.min(hover.y - 12, (wrapRef.current?.clientHeight ?? 440) - 170)),
          }}
        >
          <div className="flex items-center justify-between gap-2 mb-2">
            <Badge tone={hover.n.risk >= 0.8 ? 'red' : hover.n.risk >= 0.65 ? 'amber' : 'cyan'}>{hover.n.category}</Badge>
            <span className="font-mono2 text-[10px] text-[var(--muted)]">RISK {(hover.n.risk * 100).toFixed(0)}</span>
          </div>
          <div className="font-mono2 text-[10px] break-all text-cyan-300 mb-2.5">{hover.n.id}</div>
          <div className="grid grid-cols-2 gap-2 text-[10px]">
            <div>
              <div className="text-[var(--muted)] uppercase tracking-wider text-[8px]">Balance</div>
              <div className="font-mono2 font-semibold">{fmtBTC(hover.n.balance, 2)}</div>
            </div>
            <div>
              <div className="text-[var(--muted)] uppercase tracking-wider text-[8px]">Volume 30d</div>
              <div className="font-mono2 font-semibold">{fmtNum(Math.round(hover.n.volume))} BTC</div>
            </div>
          </div>
          {onSelect && <div className="mt-2 text-[9px] text-[var(--muted)] italic">Click node to pivot wagon wheel</div>}
        </div>
      )}
    </div>
  );
}

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useTheme } from '../lib/theme';
import { ASSET_COLORS, palette } from '../lib/palette';
import { fmtNum } from '../lib/format';

const compact = (v: number) => (v >= 1000 ? `${(v / 1000).toFixed(1)}k` : `${v}`);

function useChartTheme() {
  const { theme } = useTheme();
  const pal = palette(theme);
  const tip = {
    backgroundColor: pal.tooltipBg,
    border: `1px solid ${pal.tooltipBorder}`,
    borderRadius: 12,
    fontSize: 12,
    color: pal.strongText,
    boxShadow: '0 12px 32px -12px rgba(0,0,0,0.5)',
  } as const;
  return { pal, tip };
}

/* Monthly transaction-volume trends for BTC / ETH / USDT */
export function VolumeTrendChart({ data }: { data: any[] }) {
  const { pal, tip } = useChartTheme();
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data} barGap={3}>
        <CartesianGrid strokeDasharray="3 3" stroke={pal.grid} vertical={false} />
        <XAxis dataKey="m" tick={{ fill: pal.text, fontSize: 11 }} tickLine={false} axisLine={{ stroke: pal.grid }} />
        <YAxis tick={{ fill: pal.text, fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={compact} />
        <Tooltip contentStyle={tip} labelStyle={{ color: pal.strongText }} cursor={{ fill: pal.cursor }} />
        <Bar dataKey="BTC" fill={ASSET_COLORS.BTC} radius={[4, 4, 0, 0]} maxBarSize={22} />
        <Bar dataKey="ETH" fill={ASSET_COLORS.ETH} radius={[4, 4, 0, 0]} maxBarSize={22} />
        <Bar dataKey="USDT" fill={ASSET_COLORS.USDT} radius={[4, 4, 0, 0]} maxBarSize={22} />
      </BarChart>
    </ResponsiveContainer>
  );
}

/* Donut: asset distribution */
export function AssetDonut({ data }: { data: { name: string; value: number; share: number }[] }) {
  const { tip } = useChartTheme();
  const total = data.reduce((s, d) => s + d.value, 0);
  return (
    <div>
      <div className="relative">
        <ResponsiveContainer width="100%" height={210}>
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" innerRadius="64%" outerRadius="88%" paddingAngle={3} strokeWidth={0}>
              {data.map((d) => (
                <Cell key={d.name} fill={ASSET_COLORS[d.name] ?? '#64748b'} />
              ))}
            </Pie>
            <Tooltip contentStyle={tip} formatter={(v: any) => fmtNum(Number(v))} />
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <div className="font-mono2 text-lg font-bold">{fmtNum(total)}</div>
          <div className="text-[9px] uppercase tracking-[0.2em] text-[var(--muted)]">Total TXS</div>
        </div>
      </div>
      <div className="mt-3 space-y-1.5">
        {data.map((d) => (
          <div key={d.name} className="flex items-center gap-2 text-xs">
            <span className="w-2.5 h-2.5 rounded-sm" style={{ background: ASSET_COLORS[d.name] ?? '#64748b' }} />
            <span className="font-mono2 font-semibold w-12">{d.name}</span>
            <span className="flex-1 h-1 rounded-full bg-[var(--panel-soft)] overflow-hidden">
              <span className="block h-full rounded-full" style={{ width: `${d.share}%`, background: ASSET_COLORS[d.name] ?? '#64748b' }} />
            </span>
            <span className="font-mono2 text-[var(--muted)] w-14 text-right">{d.share.toFixed(1)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* GNN training loss curves */
export function LossCurve({ epochs, hybrid, pure }: { epochs: number[]; hybrid: number[]; pure: number[] }) {
  const { pal, tip } = useChartTheme();
  const data = epochs.map((e, i) => ({ epoch: e, 'Hybrid 19-dim': hybrid[i], 'Pure 13-dim': pure[i] }));
  return (
    <ResponsiveContainer width="100%" height={230}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke={pal.grid} vertical={false} />
        <XAxis dataKey="epoch" tick={{ fill: pal.text, fontSize: 10 }} tickLine={false} axisLine={{ stroke: pal.grid }} label={{ value: 'epoch', position: 'insideBottomRight', offset: -4, fill: pal.text, fontSize: 10 }} />
        <YAxis tick={{ fill: pal.text, fontSize: 10 }} tickLine={false} axisLine={false} domain={[0, 'auto']} />
        <Tooltip contentStyle={tip} labelStyle={{ color: pal.strongText }} />
        <Line type="monotone" dataKey="Hybrid 19-dim" stroke="#00E5FF" strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="Pure 13-dim" stroke="#a855f7" strokeWidth={2} dot={false} strokeDasharray="5 4" />
      </LineChart>
    </ResponsiveContainer>
  );
}

/* Generic single-series bar chart (histograms / frequency / distributions) */
export function MiniBars({ data, xKey, yKey, color = '#00E5FF', height = 200 }: { data: any[]; xKey: string; yKey: string; color?: string; height?: number }) {
  const { pal, tip } = useChartTheme();
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke={pal.grid} vertical={false} />
        <XAxis dataKey={xKey} tick={{ fill: pal.text, fontSize: 10 }} tickLine={false} axisLine={{ stroke: pal.grid }} interval="preserveStartEnd" />
        <YAxis tick={{ fill: pal.text, fontSize: 10 }} tickLine={false} axisLine={false} tickFormatter={compact} width={36} />
        <Tooltip contentStyle={tip} labelStyle={{ color: pal.strongText }} cursor={{ fill: pal.cursor }} />
        <Bar dataKey={yKey} fill={color} radius={[3, 3, 0, 0]} maxBarSize={26} />
      </BarChart>
    </ResponsiveContainer>
  );
}

import { useEffect, useRef } from 'react';
import { useTheme } from '../lib/theme';

/* Lightweight 3D entity-mesh globe — fibonacci sphere of nodes, rotated and
   projected to 2D canvas with proximity links + an orbital ring. No deps. */
export default function Globe3D({ size = 170 }: { size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const { theme } = useTheme();

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = `${size}px`;
    canvas.style.height = `${size}px`;

    const N = 96;
    const pts: [number, number, number][] = [];
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2;
      const r = Math.sqrt(Math.max(0, 1 - y * y));
      const th = i * 2.399963229728653; // golden angle
      pts.push([Math.cos(th) * r, y, Math.sin(th) * r]);
    }

    const accent = theme === 'dark' ? '0,229,255' : '2,132,199';
    const purple = theme === 'dark' ? '168,85,247' : '126,34,206';

    let raf = 0;
    let rot = 0;

    const draw = () => {
      rot += 0.0042;
      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, size, size);
      const cx = size / 2;
      const cy = size / 2;
      const R = size * 0.36;

      const proj = pts.map(([x, y, z]) => {
        const rx = x * Math.cos(rot) - z * Math.sin(rot);
        const rz = x * Math.sin(rot) + z * Math.cos(rot);
        return { x: cx + rx * R, y: cy + y * R * 0.98, z: rz };
      });

      /* proximity links — front of the sphere renders brighter */
      for (let i = 0; i < N; i++) {
        for (let j = i + 1; j < N; j++) {
          const a = proj[i];
          const b = proj[j];
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          if (d < R * 0.5) {
            const depth = ((a.z + b.z) / 2 + 1) / 2;
            ctx.strokeStyle = `rgba(${accent},${0.02 + depth * 0.13})`;
            ctx.lineWidth = 0.6;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      /* nodes */
      proj.forEach((p, i) => {
        const depth = (p.z + 1) / 2;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 0.8 + depth * 1.8, 0, Math.PI * 2);
        ctx.fillStyle =
          i % 8 === 0 ? `rgba(${purple},${0.2 + depth * 0.65})` : `rgba(${accent},${0.12 + depth * 0.6})`;
        ctx.fill();
      });

      /* orbital ring */
      ctx.beginPath();
      ctx.ellipse(cx, cy, R * 1.26, R * 0.4, -0.42, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(${accent},0.28)`;
      ctx.lineWidth = 1;
      ctx.stroke();
      /* satellite riding the ring */
      const sa = rot * 1.7;
      const sx = cx + Math.cos(sa) * R * 1.26 * Math.cos(-0.42) - Math.sin(sa) * R * 0.4 * Math.sin(-0.42);
      const sy = cy + Math.cos(sa) * R * 1.26 * Math.sin(-0.42) + Math.sin(sa) * R * 0.4 * Math.cos(-0.42);
      ctx.beginPath();
      ctx.arc(sx, sy, 2.4, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${purple},0.95)`;
      ctx.shadowColor = `rgba(${purple},0.9)`;
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.restore();
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [size, theme]);

  return <canvas ref={ref} className="globe-glow" aria-hidden="true" />;
}

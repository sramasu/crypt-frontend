import { useEffect, useMemo, useState } from 'react';
import { ArrowLeftRight, CalendarClock, GitFork, LayoutGrid, Search, Timer, Wallet } from 'lucide-react';
import { api } from '../../lib/api';
import { Badge, Empty, ErrBox, Glass, SectionTitle, Skeleton } from '../ui';
import { cls, fmtNum, shortHash } from '../../lib/format';
import type { CommunityRow, FeatureRow, MotifRow } from '../../lib/types';

const WINDOWS = ['1h', '2h', '4h', '6h'];

interface Combined {
  coverage: { addresses: number; transactions: number; window_days: number; window_seconds: number };
  motifs: MotifRow[];
  communities: CommunityRow[];
  consensus: { common_addresses: number; ari: number; nmi: number };
  features: FeatureRow[];
}

export default function TemporalTab() {
  const [data, setData] = useState<Combined | null>(null);
  const [err, setErr] = useState('');
  const [win, setWin] = useState('4h');
  const [featQuery, setFeatQuery] = useState('');

  useEffect(() => {
    (async () => {
      try {
        setData(await api('/api/combined/results'));
      } catch (ex: any) {
        setErr(ex.message ?? 'Failed to load temporal motif payload');
      }
    })();
  }, []);

  const motifNames = useMemo(() => {
    if (!data) return [];
    const seen: string[] = [];
    data.motifs.forEach((m) => {
      if (!seen.includes(m.motif)) seen.push(m.motif);
    });
    return seen;
  }, [data]);

  const maxMatches = useMemo(() => (data ? Math.max(...data.motifs.map((m) => m.matches), 1) : 1), [data]);

  const windowRows = useMemo(() => (data ? data.motifs.filter((m) => m.window === win).sort((a, b) => b.matches - a.matches) : []), [data, win]);

  const windowTotals = useMemo(
    () =>
      windowRows.reduce(
        (acc, m) => ({ matches: acc.matches + m.matches, addresses: acc.addresses + m.addresses, txs: acc.txs + m.txs }),
        { matches: 0, addresses: 0, txs: 0 },
      ),
    [windowRows],
  );

  const features = useMemo(
    () => (data ? data.features.filter((f) => !featQuery || f.address.toLowerCase().includes(featQuery.toLowerCase())) : []),
    [data, featQuery],
  );

  if (err) return <ErrBox msg={err} />;
  if (!data)
    return (
      <div className="space-y-4">
        <Skeleton className="h-28" />
        <Skeleton className="h-72" />
      </div>
    );

  const cov = data.coverage;

  return (
    <div className="space-y-4">
      {/* Bitcoin graph coverage KPIs */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          { icon: Wallet, label: 'Bitcoin Graph Addresses', value: fmtNum(cov.addresses), tone: 'text-cyan-400 border-cyan-400/25 bg-cyan-400/10' },
          { icon: ArrowLeftRight, label: 'Graph Transactions', value: fmtNum(cov.transactions), tone: 'text-purple-400 border-purple-400/25 bg-purple-400/10' },
          { icon: CalendarClock, label: 'Coverage Window', value: `${cov.window_days} days`, tone: 'text-emerald-400 border-emerald-400/25 bg-emerald-400/10' },
          { icon: Timer, label: 'Window Seconds', value: fmtNum(cov.window_seconds), tone: 'text-amber-400 border-amber-400/25 bg-amber-400/10' },
        ].map((k) => (
          <Glass key={k.label} hover className="p-4 flex items-center gap-3">
            <span className={cls('p-2 rounded-xl border', k.tone)}>
              <k.icon size={16} />
            </span>
            <div>
              <div className="font-mono2 text-lg font-bold">{k.value}</div>
              <div className="text-[9px] uppercase tracking-[0.14em] text-[var(--muted)]">{k.label}</div>
            </div>
          </Glass>
        ))}
      </div>

      {/* 11-motif multi-window sensitivity matrix */}
      <Glass className="p-0 overflow-hidden">
        <div className="p-5 pb-3">
          <SectionTitle
            icon={LayoutGrid}
            title="11-Motif Multi-Window Sensitivity Matrix"
            sub="8 baseline motifs (DYNAMIC_TRIAD, CAW, M1–M6) + 3 entity-discriminative motifs (E1–E3)"
          />
        </div>
        <div className="overflow-x-auto">
          <table className="table-base w-full">
            <thead>
              <tr>
                <th>Motif</th>
                <th>Class</th>
                {WINDOWS.map((w) => (
                  <th key={w} className="text-right">
                    {w} window
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {motifNames.map((name) => {
                const cells = WINDOWS.map((w) => data.motifs.find((m) => m.motif === name && m.window === w));
                const cat = cells.find(Boolean)?.category ?? 'baseline';
                return (
                  <tr key={name}>
                    <td className="font-mono2 font-semibold text-[12px]">{name}</td>
                    <td>
                      <Badge tone={cat === 'entity' ? 'purple' : 'slate'}>{cat === 'entity' ? 'entity-discriminative' : 'baseline'}</Badge>
                    </td>
                    {cells.map((c, i) => (
                      <td key={i} className="text-right">
                        <span
                          className="inline-block min-w-[64px] px-2 py-1 rounded-md font-mono2 text-[11px]"
                          style={{ background: `rgba(0,229,255,${0.04 + (c ? (c.matches / maxMatches) * 0.3 : 0)})` }}
                        >
                          {c ? fmtNum(c.matches) : '—'}
                        </span>
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Glass>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Communities & consensus */}
        <Glass className="p-0 overflow-hidden">
          <div className="p-5 pb-3">
            <SectionTitle icon={GitFork} title="Communities & Consensus" sub="Louvain vs Leiden partition agreement" />
          </div>
          <table className="table-base w-full">
            <thead>
              <tr>
                <th>Algorithm</th>
                <th className="text-right">Communities</th>
                <th className="text-right">Modularity</th>
              </tr>
            </thead>
            <tbody>
              {data.communities.map((c) => (
                <tr key={c.algorithm}>
                  <td className="font-semibold text-[12px]">{c.algorithm}</td>
                  <td className="text-right font-mono2">{fmtNum(c.communities)}</td>
                  <td className="text-right font-mono2 text-cyan-300">{c.modularity.toFixed(4)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="p-4 grid grid-cols-3 gap-2.5 border-t border-[var(--border)]">
            <div className="glass rounded-xl p-3 text-center">
              <div className="font-mono2 text-base font-bold text-emerald-400">{fmtNum(data.consensus.common_addresses)}</div>
              <div className="text-[8px] uppercase tracking-[0.14em] text-[var(--muted)] mt-1">Common Addresses</div>
            </div>
            <div className="glass rounded-xl p-3 text-center">
              <div className="font-mono2 text-base font-bold text-cyan-300">{data.consensus.ari.toFixed(4)}</div>
              <div className="text-[8px] uppercase tracking-[0.14em] text-[var(--muted)] mt-1">ARI</div>
            </div>
            <div className="glass rounded-xl p-3 text-center">
              <div className="font-mono2 text-base font-bold text-purple-300">{data.consensus.nmi.toFixed(4)}</div>
              <div className="text-[8px] uppercase tracking-[0.14em] text-[var(--muted)] mt-1">NMI</div>
            </div>
          </div>
        </Glass>

        {/* Interactive window results explorer */}
        <Glass className="p-5">
          <SectionTitle
            icon={Timer}
            title="Window Results Explorer"
            sub="motif matches decomposed per aggregation window"
            right={
              <select className="field !w-24 !py-1.5 font-mono2" value={win} onChange={(e) => setWin(e.target.value)}>
                {WINDOWS.map((w) => (
                  <option key={w} value={w}>
                    {w}
                  </option>
                ))}
              </select>
            }
          />
          <div className="grid grid-cols-3 gap-2.5 mb-4">
            <div className="glass rounded-xl p-3 text-center">
              <div className="font-mono2 text-base font-bold">{fmtNum(windowTotals.matches)}</div>
              <div className="text-[8px] uppercase tracking-[0.14em] text-[var(--muted)] mt-1">Motif Matches</div>
            </div>
            <div className="glass rounded-xl p-3 text-center">
              <div className="font-mono2 text-base font-bold">{fmtNum(windowTotals.addresses)}</div>
              <div className="text-[8px] uppercase tracking-[0.14em] text-[var(--muted)] mt-1">Addresses</div>
            </div>
            <div className="glass rounded-xl p-3 text-center">
              <div className="font-mono2 text-base font-bold">{fmtNum(windowTotals.txs)}</div>
              <div className="text-[8px] uppercase tracking-[0.14em] text-[var(--muted)] mt-1">Transactions</div>
            </div>
          </div>
          <div className="space-y-2 max-h-[240px] overflow-y-auto pr-1">
            {windowRows.map((m) => (
              <div key={m.motif} className="flex items-center gap-3">
                <span className="font-mono2 text-[10px] w-32 shrink-0">{m.motif}</span>
                <span className="flex-1 h-2 rounded-full bg-[var(--panel-soft)] overflow-hidden">
                  <span
                    className={cls('block h-full rounded-full', m.category === 'entity' ? 'bg-purple-400' : 'bg-cyan-400')}
                    style={{ width: `${(m.matches / (windowRows[0]?.matches ?? 1)) * 100}%` }}
                  />
                </span>
                <span className="font-mono2 text-[10px] text-[var(--muted)] w-14 text-right">{fmtNum(m.matches)}</span>
              </div>
            ))}
          </div>
        </Glass>
      </div>

      {/* Top-100 address motif features */}
      <Glass className="p-0 overflow-hidden">
        <div className="p-5 pb-3 flex flex-wrap items-center justify-between gap-3">
          <SectionTitle icon={Wallet} title="Top 100 Address Motif Features" sub="participation-ranked structural embeddings" />
          <div className="relative w-64">
            <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
            <input className="field !pl-8 !py-2 font-mono2" placeholder="Filter address…" value={featQuery} onChange={(e) => setFeatQuery(e.target.value)} spellCheck={false} />
          </div>
        </div>
        {features.length === 0 ? (
          <Empty msg="No address features match the filter." />
        ) : (
          <div className="overflow-x-auto max-h-[420px] overflow-y-auto">
            <table className="table-base w-full">
              <thead className="sticky top-0 bg-[var(--panel-solid)] z-10">
                <tr>
                  <th>#</th>
                  <th>Address</th>
                  <th className="text-right">Participations</th>
                  <th className="text-right">Fan-in</th>
                  <th className="text-right">Fan-out</th>
                  <th className="text-right">Rapid Relay</th>
                </tr>
              </thead>
              <tbody>
                {features.map((f, i) => (
                  <tr key={f.id}>
                    <td className="font-mono2 text-[var(--muted)]">{String(i + 1).padStart(3, '0')}</td>
                    <td className="font-mono2 text-cyan-300">{shortHash(f.address, 10)}</td>
                    <td className="text-right font-mono2">{fmtNum(f.participations)}</td>
                    <td className="text-right font-mono2 text-emerald-300">{fmtNum(f.fan_in)}</td>
                    <td className="text-right font-mono2 text-purple-300">{fmtNum(f.fan_out)}</td>
                    <td className="text-right font-mono2 text-amber-300">{fmtNum(f.rapid_relay)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Glass>
    </div>
  );
}

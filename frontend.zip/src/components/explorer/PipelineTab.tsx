import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Boxes,
  BrainCircuit,
  Crosshair,
  Database,
  FlaskConical,
  Link2,
  Play,
  Search,
  Share2,
  Terminal,
} from 'lucide-react';
import { api, post } from '../../lib/api';
import { Badge, Btn, ConfPill, Empty, ErrBox, Glass, Modal, SectionTitle, Skeleton, useToast } from '../ui';
import { LossCurve, MiniBars } from '../charts';
import { EgoNet } from '../WagonWheel';
import { cls, fmtBTC, fmtNum, riskTone, shortHash, timeAgo } from '../../lib/format';
import type { ClusterRow, MembershipRow, StagePayload } from '../../lib/types';

const STAGES = [
  { id: 's1', icon: FlaskConical, label: 'Stage 1 · Heuristics', api: 1 },
  { id: 's2', icon: Boxes, label: 'Stage 2 · Clustering', api: 2 },
  { id: 's3', icon: BrainCircuit, label: 'Stage 3 · Sub-Graph GNN', api: 3 },
  { id: 's4', icon: Share2, label: 'Stage 4 · Sub-Graph Viz', api: 4 },
  { id: 's5', icon: Database, label: 'Stage 5 · GraphDB Communities', api: 5 },
  { id: 'fx', icon: Crosshair, label: 'Forensic Inspector', api: 0 },
] as const;

type StageId = (typeof STAGES)[number]['id'];

export default function PipelineTab({ selected }: { selected: string }) {
  const [stage, setStage] = useState<StageId>('s1');
  const [cache, setCache] = useState<Record<number, StagePayload>>({});
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');
  const [memberships, setMemberships] = useState<MembershipRow[]>([]);
  const [clusters, setClusters] = useState<ClusterRow[]>([]);
  const [modalCluster, setModalCluster] = useState<any>(null);
  const [pair, setPair] = useState({ a: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh', b: 'bc1qcr8te4kr09gc68ej0ln9zpllxnnzf0a5u0x9h2' });
  const [pairRes, setPairRes] = useState<any>(null);
  const [pairBusy, setPairBusy] = useState(false);
  const [egoCenter, setEgoCenter] = useState(selected);
  const [ego, setEgo] = useState<{ ring1: any[]; ring2: Record<string, any[]> } | null>(null);
  const [egoBusy, setEgoBusy] = useState(false);
  const [fxQuery, setFxQuery] = useState('');
  const [fx, setFx] = useState<any>(null);
  const [fxBusy, setFxBusy] = useState(false);
  const toast = useToast();

  /* reference data for modals + inspector chips */
  useEffect(() => {
    (async () => {
      try {
        const [m, hr] = await Promise.all([api('/api/dashboard/group-memberships'), api('/api/dashboard/high-risk')]);
        setMemberships(m);
        setClusters(hr.high_risk_groups ?? []);
      } catch {
        /* non-fatal */
      }
    })();
  }, []);

  /* lazy stage fetch */
  useEffect(() => {
    const meta = STAGES.find((s) => s.id === stage);
    if (!meta || meta.api === 0 || cache[meta.api]) return;
    (async () => {
      setLoading(true);
      setErr('');
      try {
        const payload = await api(`/api/pipeline/stage${meta.api}`);
        setCache((c) => ({ ...c, [meta.api]: payload }));
      } catch (ex: any) {
        setErr(ex.message ?? 'Stage payload failed');
      } finally {
        setLoading(false);
      }
    })();
  }, [stage, cache]);

  const runPairwise = async () => {
    if (!pair.a.trim() || !pair.b.trim()) return toast.push('Both addresses are required', 'red');
    setPairBusy(true);
    try {
      setPairRes(await post('/api/pipeline/pairwise', { a: pair.a.trim(), b: pair.b.trim() }));
    } catch (ex: any) {
      toast.push(ex.message ?? 'Pairwise inference failed', 'red');
    } finally {
      setPairBusy(false);
    }
  };

  const loadEgo = async () => {
    if (!egoCenter.trim()) return;
    setEgoBusy(true);
    try {
      const w1 = await api(`/api/explorer/wagon-wheel?address=${encodeURIComponent(egoCenter.trim())}`);
      const ring1 = (w1.destinations ?? []).map((d: any) => ({ address: d.counterparty, label: d.label, category: d.category }));
      const ring2: Record<string, any[]> = {};
      await Promise.all(
        (w1.destinations ?? []).slice(0, 3).map(async (d: any) => {
          try {
            const w2 = await api(`/api/explorer/wagon-wheel?address=${encodeURIComponent(d.counterparty)}`);
            ring2[d.counterparty] = (w2.destinations ?? []).map((x: any) => ({ address: x.counterparty, label: x.label }));
          } catch {
            ring2[d.counterparty] = [];
          }
        }),
      );
      setEgo({ ring1, ring2 });
      if (!ring1.length) toast.push('No 1-hop neighbourhood indexed for this address', 'amber');
    } catch (ex: any) {
      toast.push(ex.message ?? 'Ego-net extraction failed', 'red');
    } finally {
      setEgoBusy(false);
    }
  };

  const inspect = async (addr: string) => {
    if (!addr.trim()) return;
    setFxBusy(true);
    try {
      setFx(await api(`/api/forensic/inspect?address=${encodeURIComponent(addr.trim())}`));
    } catch (ex: any) {
      setFx(null);
      toast.push(ex.message ?? 'No intelligence dossier for this address', 'red');
    } finally {
      setFxBusy(false);
    }
  };

  const s1 = cache[1];
  const s2 = cache[2];
  const s3 = cache[3];
  const s5 = cache[5];

  const chips = memberships.slice(0, 3).map((m) => m.address);

  return (
    <div>
      {/* sub-tab pills */}
      <div className="flex gap-1.5 mb-4 overflow-x-auto pb-1">
        {STAGES.map((s) => (
          <button
            key={s.id}
            onClick={() => setStage(s.id)}
            className={cls(
              'flex items-center gap-2 px-3.5 py-2 rounded-xl text-[10.5px] font-semibold tracking-wide whitespace-nowrap border transition-all',
              stage === s.id
                ? 'bg-purple-400/12 text-purple-300 border-purple-400/40 shadow-[0_0_16px_-6px_rgba(168,85,247,0.6)]'
                : 'text-[var(--muted)] border-[var(--border)] hover:bg-[var(--panel-soft)] hover:text-[var(--text)]',
            )}
          >
            <s.icon size={13} />
            {s.label}
          </button>
        ))}
      </div>

      {err && <ErrBox msg={err} />}
      {loading && <Skeleton className="h-72" />}

      {/* ---------------- STAGE 1: HEURISTICS ---------------- */}
      {!loading && stage === 's1' && s1 && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: 'Precision', v: s1.metrics.precision, tone: 'from-cyan-400 to-sky-500' },
              { label: 'Recall', v: s1.metrics.recall, tone: 'from-emerald-400 to-teal-500' },
              { label: 'F1-Score', v: s1.metrics.f1, tone: 'from-purple-400 to-fuchsia-500' },
            ].map((m) => (
              <Glass key={m.label} hover className="p-5">
                <div className="text-[10px] uppercase tracking-[0.16em] text-[var(--muted)]">{m.label}</div>
                <div className="font-mono2 text-2xl font-bold mt-1.5 metric-glow">{(m.v * 100).toFixed(2)}%</div>
                <div className="mt-3 h-2 rounded-full bg-[var(--panel-soft)] overflow-hidden">
                  <div className={cls('h-full rounded-full bg-gradient-to-r', m.tone)} style={{ width: `${m.v * 100}%` }} />
                </div>
              </Glass>
            ))}
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <Glass className="p-0 overflow-hidden">
              <div className="p-5 pb-3">
                <SectionTitle icon={FlaskConical} title="Heuristic Rule Performance" sub={`${fmtNum(s1.metrics.support)} addresses evaluated`} />
              </div>
              <table className="table-base w-full">
                <thead>
                  <tr>
                    <th>Rule</th>
                    <th className="text-right">Matched</th>
                    <th className="text-right">Precision</th>
                  </tr>
                </thead>
                <tbody>
                  {s1.metrics.rules.map((r: any) => (
                    <tr key={r.rule}>
                      <td className="text-[12px] font-medium">{r.rule}</td>
                      <td className="text-right font-mono2">{fmtNum(r.matched)}</td>
                      <td className="text-right">
                        <ConfPill value={r.precision * 100} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Glass>
            <Glass className="p-5">
              <SectionTitle icon={Terminal} title="Heuristic Execution Log" sub="CIOH · change-address · reuse sweeps" />
              <div className="rounded-xl bg-[#050a14] border border-[var(--border)] p-4 font-mono2 text-[10.5px] leading-6 text-emerald-300/90 overflow-x-auto max-h-[260px] overflow-y-auto">
                {s1.logs.map((l, i) => (
                  <div key={i}>
                    <span className="text-cyan-500">›</span> {l}
                  </div>
                ))}
              </div>
            </Glass>
          </div>
        </div>
      )}

      {/* ---------------- STAGE 2: CLUSTERING ---------------- */}
      {!loading && stage === 's2' && s2 && (
        <div className="space-y-4">
          <Glass className="p-5">
            <SectionTitle
              icon={Boxes}
              title="Entity Resolution Distribution"
              sub={`${fmtNum(s2.metrics.validated)} validated memberships · singleton rate ${(s2.metrics.singleton_rate * 100).toFixed(1)}%`}
            />
            <MiniBars data={s2.metrics.distribution} xKey="name" yKey="value" color="#a855f7" height={220} />
          </Glass>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {s2.metrics.clusters.map((c: any) => (
              <Glass key={c.id} hover className="p-5 cursor-pointer" >
                <div onClick={() => setModalCluster(c)}>
                  <div className="flex items-center justify-between mb-2">
                    <Badge tone="purple">{c.id}</Badge>
                    <span className="font-mono2 text-[10px] text-[var(--muted)]">purity {(c.purity * 100).toFixed(0)}%</span>
                  </div>
                  <div className="text-sm font-semibold">{c.name}</div>
                  <div className="mt-3 flex items-end justify-between">
                    <div>
                      <div className="font-mono2 text-xl font-bold">{fmtNum(c.members)}</div>
                      <div className="text-[9px] uppercase tracking-[0.14em] text-[var(--muted)]">member addresses</div>
                    </div>
                    <span className="text-[10px] text-cyan-400 font-mono2">inspect →</span>
                  </div>
                  <div className="mt-2.5 h-1.5 rounded-full bg-[var(--panel-soft)] overflow-hidden">
                    <div className="h-full rounded-full bg-gradient-to-r from-purple-400 to-cyan-400" style={{ width: `${c.purity * 100}%` }} />
                  </div>
                </div>
              </Glass>
            ))}
          </div>
        </div>
      )}

      {/* ---------------- STAGE 3: SUB-GRAPH GNN ---------------- */}
      {!loading && stage === 's3' && s3 && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {[
              { title: 'Hybrid GNN · 19-dim', m: s3.metrics.hybrid, tone: 'cyan', best: true },
              { title: 'Pure GNN · 13-dim', m: s3.metrics.pure, tone: 'purple', best: false },
            ].map((g) => (
              <Glass key={g.title} hover className="p-5 relative overflow-hidden">
                {g.best && <div className="absolute top-0 right-0 px-3 py-1 text-[8px] font-bold tracking-[0.2em] bg-cyan-400/15 text-cyan-300 rounded-bl-xl border-l border-b border-cyan-400/30">SELECTED</div>}
                <div className="flex items-center gap-2">
                  <BrainCircuit size={16} className={g.tone === 'cyan' ? 'text-cyan-400' : 'text-purple-400'} />
                  <span className="text-sm font-semibold">{g.title}</span>
                  <Badge tone={g.tone}>{g.m.dims}-dim features</Badge>
                </div>
                <div className="grid grid-cols-4 gap-2 mt-4">
                  {[
                    ['F1', g.m.f1],
                    ['AUC', g.m.auc],
                    ['Prec', g.m.precision],
                    ['Rec', g.m.recall],
                  ].map(([l, v]: any) => (
                    <div key={l} className="glass rounded-xl p-2.5 text-center">
                      <div className={cls('font-mono2 text-sm font-bold', g.tone === 'cyan' ? 'text-cyan-300' : 'text-purple-300')}>
                        {(v * 100).toFixed(1)}
                      </div>
                      <div className="text-[8px] uppercase tracking-[0.16em] text-[var(--muted)] mt-0.5">{l}</div>
                    </div>
                  ))}
                </div>
              </Glass>
            ))}
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <Glass className="p-5">
              <SectionTitle icon={BrainCircuit} title="Training Loss Curves" sub="binary cross-entropy per epoch · hybrid vs pure" />
              <LossCurve epochs={s3.metrics.epochs} hybrid={s3.metrics.hybrid_loss} pure={s3.metrics.pure_loss} />
            </Glass>

            {/* Pairwise link prediction tester */}
            <Glass className="p-5">
              <SectionTitle icon={Link2} title="Pairwise Link Prediction" sub="same-entity probability from the hybrid model" />
              <div className="space-y-2.5">
                <input className="field font-mono2" value={pair.a} onChange={(e) => setPair({ ...pair, a: e.target.value })} spellCheck={false} />
                <input className="field font-mono2" value={pair.b} onChange={(e) => setPair({ ...pair, b: e.target.value })} spellCheck={false} />
                <Btn onClick={runPairwise} busy={pairBusy} className="w-full">
                  <Play size={13} /> Compute Link Score
                </Btn>
              </div>
              {pairRes && (
                <div className="mt-4 glass rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Badge tone={pairRes.linked ? 'red' : 'emerald'}>{pairRes.linked ? 'SAME-ENTITY LINK' : 'NO LINK'}</Badge>
                    <span className="font-mono2 text-[10px] text-[var(--muted)]">p = {pairRes.probability}</span>
                  </div>
                  <div className="font-mono2 text-3xl font-bold metric-glow">{(pairRes.score * 100).toFixed(1)}%</div>
                  <div className="mt-2 h-2 rounded-full bg-[var(--panel-soft)] overflow-hidden">
                    <div className={cls('h-full rounded-full', pairRes.linked ? 'bg-gradient-to-r from-red-400 to-amber-400' : 'bg-gradient-to-r from-emerald-400 to-cyan-400')} style={{ width: `${pairRes.score * 100}%` }} />
                  </div>
                </div>
              )}
              <div className="mt-4">
                <div className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)] mb-2">Reference evaluations</div>
                <div className="space-y-1.5">
                  {s3.metrics.tests.map((t: any, i: number) => (
                    <div key={i} className="flex items-center gap-2 text-[10px] font-mono2">
                      <span className="text-cyan-300">{shortHash(t.a, 5)}</span>
                      <span className="text-[var(--muted)]">↔</span>
                      <span className="text-cyan-300">{shortHash(t.b, 5)}</span>
                      <span className="flex-1 h-1 rounded-full bg-[var(--panel-soft)] overflow-hidden">
                        <span className="block h-full bg-gradient-to-r from-cyan-400 to-purple-400" style={{ width: `${t.score * 100}%` }} />
                      </span>
                      <span className={cls('font-bold', t.score >= 0.75 ? 'text-red-300' : 'text-emerald-300')}>{(t.score * 100).toFixed(0)}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </Glass>
          </div>
        </div>
      )}

      {/* ---------------- STAGE 4: SUB-GRAPH VIZ ---------------- */}
      {stage === 's4' && (
        <Glass className="p-5">
          <SectionTitle icon={Share2} title="2-Hop Local Ego-Net" sub="neighbourhood extraction around any indexed address" />
          <div className="flex flex-wrap gap-2.5 mb-4">
            <input className="field font-mono2 !w-auto flex-1 min-w-[260px]" value={egoCenter} onChange={(e) => setEgoCenter(e.target.value)} spellCheck={false} />
            <Btn onClick={loadEgo} busy={egoBusy}>
              <Play size={13} /> Extract Ego-Net
            </Btn>
          </div>
          {ego ? (
            <div className="max-w-[680px] mx-auto">
              <EgoNet center={egoCenter.trim()} ring1={ego.ring1} ring2={ego.ring2} />
            </div>
          ) : (
            <Empty msg={egoBusy ? 'Extracting neighbourhood…' : 'Run an extraction to render the 2-hop ego network.'} />
          )}
        </Glass>
      )}

      {/* ---------------- STAGE 5: GRAPHDB COMMUNITIES ---------------- */}
      {!loading && stage === 's5' && s5 && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { label: 'Louvain Partition Modularity', v: s5.metrics.modularity.louvain, tone: 'text-cyan-300' },
              { label: 'Leiden Partition Modularity', v: s5.metrics.modularity.leiden, tone: 'text-purple-300' },
            ].map((m) => (
              <Glass key={m.label} hover className="p-5">
                <div className="text-[10px] uppercase tracking-[0.16em] text-[var(--muted)]">{m.label}</div>
                <div className={cls('font-mono2 text-3xl font-bold mt-2 metric-glow', m.tone)}>{m.v.toFixed(4)}</div>
              </Glass>
            ))}
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <Glass className="p-5">
              <SectionTitle icon={Database} title="Community Size Distribution" sub="address count per community bucket" />
              <MiniBars data={s5.metrics.sizes} xKey="bucket" yKey="count" color="#10b981" height={220} />
            </Glass>
            <Glass className="p-0 overflow-hidden">
              <div className="p-5 pb-3">
                <SectionTitle icon={Database} title="Dominant Communities" sub="largest resolved partitions" />
              </div>
              <table className="table-base w-full">
                <thead>
                  <tr>
                    <th>Community</th>
                    <th>Label</th>
                    <th className="text-right">Size</th>
                  </tr>
                </thead>
                <tbody>
                  {s5.metrics.top.map((c: any) => (
                    <tr key={c.id}>
                      <td className="font-mono2 text-cyan-300">{c.id}</td>
                      <td className="text-[11px]">{c.label}</td>
                      <td className="text-right font-mono2">{fmtNum(c.size)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Glass>
          </div>
        </div>
      )}

      {/* ---------------- FORENSIC INSPECTOR ---------------- */}
      {stage === 'fx' && (
        <div className="space-y-4">
          <Glass className="p-5">
            <SectionTitle icon={Crosshair} title="Deep Shadow Address Profiling" sub="dossier synthesis · counterparty tracking" />
            <div className="flex flex-wrap gap-2.5">
              <div className="relative flex-1 min-w-[260px]">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]" />
                <input
                  className="field font-mono2 !pl-8"
                  placeholder="Target address for deep profiling…"
                  value={fxQuery}
                  onChange={(e) => setFxQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && inspect(fxQuery)}
                  spellCheck={false}
                />
              </div>
              <Btn onClick={() => inspect(fxQuery)} busy={fxBusy}>
                <Crosshair size={13} /> Profile
              </Btn>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              <span className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)] mr-1">High-interest targets</span>
              {chips.map((c) => (
                <button
                  key={c}
                  onClick={() => { setFxQuery(c); inspect(c); }}
                  className="px-2.5 py-1 rounded-lg text-[10px] font-mono2 border border-[var(--border)] text-cyan-300 hover:bg-cyan-400/10 hover:border-cyan-400/40 transition-all"
                >
                  {shortHash(c, 7)}
                </button>
              ))}
            </div>
          </Glass>

          {fx && (
            <>
              <Glass className="p-5">
                <div className="flex flex-wrap items-center gap-2 mb-4">
                  <Badge tone={riskTone(fx.profile.risk_index)}>RISK {fx.profile.risk_index.toFixed(2)}</Badge>
                  <Badge tone="purple">{fx.profile.cluster_id ?? 'UNCLUSTERED'}{fx.profile.cluster_name ? ` · ${fx.profile.cluster_name}` : ''}</Badge>
                  <Badge tone="cyan">{fx.profile.category}</Badge>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    ['Balance', fmtBTC(fx.profile.balance, 4)],
                    ['Turnover', fmtBTC(fx.profile.turnover, 2)],
                    ['Peak Transfer', fmtBTC(fx.profile.peak_transfer, 2)],
                    ['Chain', fx.profile.chain],
                    ['First Seen', timeAgo(fx.profile.first_seen)],
                    ['Last Active', timeAgo(fx.profile.last_active)],
                    ['Counterparties', fmtNum(fx.counterparties.length)],
                    ['Recent TXs', fmtNum(fx.recent.length)],
                  ].map(([l, v]: any) => (
                    <div key={l} className="glass rounded-xl p-3">
                      <div className="text-[8px] uppercase tracking-[0.16em] text-[var(--muted)]">{l}</div>
                      <div className="font-mono2 text-sm font-bold mt-1">{v}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 space-y-1.5">
                  {fx.assessment.map((a: string, i: number) => (
                    <div key={i} className="flex items-start gap-2 text-[11px] text-[var(--muted)]">
                      <AlertTriangle size={12} className="text-amber-400 shrink-0 mt-0.5" />
                      <span>{a}</span>
                    </div>
                  ))}
                </div>
              </Glass>

              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                <Glass className="p-0 overflow-hidden">
                  <div className="p-5 pb-3">
                    <SectionTitle icon={Share2} title="Counterparty Tracking" sub="indexed flow relationships" />
                  </div>
                  {fx.counterparties.length === 0 ? (
                    <Empty msg="No indexed counterparties." />
                  ) : (
                    <table className="table-base w-full">
                      <thead>
                        <tr>
                          <th>Address</th>
                          <th>Label</th>
                          <th>Dir</th>
                          <th className="text-right">Share</th>
                        </tr>
                      </thead>
                      <tbody>
                        {fx.counterparties.map((c: any, i: number) => (
                          <tr key={i}>
                            <td className="font-mono2 text-cyan-300">{shortHash(c.address, 8)}</td>
                            <td className="text-[11px]">{c.label ?? '—'}</td>
                            <td>
                              <Badge tone={c.direction === 'in' ? 'emerald' : 'amber'}>{c.direction}</Badge>
                            </td>
                            <td className="text-right font-mono2">{c.pct != null ? `${c.pct.toFixed(1)}%` : '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </Glass>
                <Glass className="p-0 overflow-hidden">
                  <div className="p-5 pb-3">
                    <SectionTitle icon={Terminal} title="Recent Transactions" sub="latest indexed movements" />
                  </div>
                  {fx.recent.length === 0 ? (
                    <Empty msg="No recent transactions." />
                  ) : (
                    <table className="table-base w-full">
                      <thead>
                        <tr>
                          <th>Hash</th>
                          <th className="text-right">Amount</th>
                          <th className="text-right">Age</th>
                        </tr>
                      </thead>
                      <tbody>
                        {fx.recent.map((t: any) => (
                          <tr key={t.id}>
                            <td className="font-mono2 text-cyan-300">{shortHash(t.tx_hash, 8)}</td>
                            <td className="text-right font-mono2 text-amber-300">
                              {fmtNum(t.amount)} {t.asset}
                            </td>
                            <td className="text-right font-mono2 text-[10px] text-[var(--muted)]">{timeAgo(t.timestamp)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </Glass>
              </div>
            </>
          )}
        </div>
      )}

      {/* Cluster inspector modal */}
      <Modal open={!!modalCluster} onClose={() => setModalCluster(null)} title={<span>Cluster Inspector — <span className="font-mono2 text-purple-300">{modalCluster?.id}</span></span>} wide>
        {modalCluster && (
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <Badge tone="purple">{modalCluster.id}</Badge>
              <span className="text-sm font-semibold">{modalCluster.name}</span>
              <Badge tone="cyan">purity {(modalCluster.purity * 100).toFixed(0)}%</Badge>
              <Badge tone="slate">{fmtNum(modalCluster.members)} members</Badge>
            </div>
            {clusters.find((c) => c.cluster_id === modalCluster.id) && (
              <p className="text-[11px] text-[var(--muted)] mb-4">
                Entity type: <span className="text-[var(--text)]">{clusters.find((c) => c.cluster_id === modalCluster.id)?.entity_type}</span> · aggregate
                volume <span className="font-mono2 text-amber-300"> {fmtBTC(clusters.find((c) => c.cluster_id === modalCluster.id)?.volume_btc, 0)}</span>
              </p>
            )}
            <div className="text-[9px] uppercase tracking-[0.16em] text-[var(--muted)] mb-2">Validated memberships (sample)</div>
            <div className="space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
              {memberships.filter((m) => m.cluster_id === modalCluster.id).length === 0 ? (
                <Empty msg="No sampled memberships for this cluster." />
              ) : (
                memberships
                  .filter((m) => m.cluster_id === modalCluster.id)
                  .map((m) => (
                    <div key={m.id} className="glass rounded-xl px-3.5 py-2.5 flex items-center gap-3">
                      <span className="font-mono2 text-[11px] text-cyan-300 flex-1 break-all">{m.address}</span>
                      <Badge tone="slate">{m.heuristic}</Badge>
                      <ConfPill value={m.confidence} />
                    </div>
                  ))
              )}
            </div>
          </div>
        )}
      </Modal>

      {toast.node}
    </div>
  );
}

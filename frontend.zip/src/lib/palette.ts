export const palette = (theme: 'dark' | 'light') => ({
  text: theme === 'dark' ? '#8b9bb4' : '#5b6b85',
  strongText: theme === 'dark' ? '#e6edf7' : '#0e1a2e',
  grid: theme === 'dark' ? 'rgba(148,163,184,0.12)' : 'rgba(15,23,42,0.1)',
  tooltipBg: theme === 'dark' ? '#0d1528' : '#ffffff',
  tooltipBorder: theme === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(15,23,42,0.12)',
  edge: theme === 'dark' ? 'rgba(0,229,255,0.22)' : 'rgba(2,132,199,0.3)',
  cursor: theme === 'dark' ? 'rgba(148,163,184,0.08)' : 'rgba(15,23,42,0.05)',
});

export const CAT_COLORS: Record<string, string> = {
  Exchange: '#00E5FF',
  Mixer: '#a855f7',
  Darknet: '#ef4444',
  Ransomware: '#f59e0b',
  'Mining Pool': '#10b981',
  DeFi: '#34d399',
  Gambling: '#f472b6',
  Dormant: '#64748b',
  Foundation: '#38bdf8',
  'Cold Storage': '#94a3b8',
  'State APT': '#ef4444',
  Bridge: '#22d3ee',
  Treasury: '#10b981',
  Unknown: '#94a3b8',
};

export const ASSET_COLORS: Record<string, string> = {
  BTC: '#f59e0b',
  ETH: '#a855f7',
  USDT: '#10b981',
};

export const CHAIN_TONE: Record<string, string> = {
  Bitcoin: 'amber',
  Ethereum: 'purple',
  Tether: 'emerald',
  BTC: 'amber',
  ETH: 'purple',
  USDT: 'emerald',
};

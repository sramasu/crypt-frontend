export interface AddressRow {
  id: number;
  address: string;
  chain: string;
  risk_index: number;
  balance: number;
  turnover: number;
  peak_transfer: number;
  cluster_id: string | null;
  cluster_name?: string | null;
  category: string;
  first_seen: string;
  last_active: string;
}

export interface TxRow {
  id: number;
  tx_hash: string;
  from_address: string;
  to_address: string;
  amount: number;
  asset: string;
  fee: number;
  risk_level: string;
  timestamp: string;
}

export interface ClusterRow {
  id: number;
  cluster_id: string;
  name: string;
  entity_type: string;
  risk_level: string;
  member_count: number;
  volume_btc: number;
}

export interface MembershipRow {
  id: number;
  address: string;
  cluster_id: string;
  cluster_name?: string;
  heuristic: string;
  confidence: number;
}

export interface SecurityEvent {
  id: number;
  severity: string;
  title: string;
  description: string;
  event_type: string;
  created_at: string;
}

export interface FlowRow {
  id: number;
  center_address: string;
  counterparty: string;
  label: string;
  pct: number;
  volume: number;
  direction: string;
  category?: string;
  risk?: number;
}

export interface GNode {
  id: string;
  label: string;
  category: string;
  balance: number;
  volume: number;
  risk: number;
}

export interface GEdge {
  source: string;
  target: string;
  value: number;
}

export interface TaintMethod {
  id: number;
  method: string;
  mtype: string;
  conserving: boolean;
  tainted_outpoints: number;
  tainted_sats: number;
  max_hops: number;
  latency_ms: number;
}

export interface TaintExposed {
  id: number;
  address: string;
  hop_distance: number;
  exposure_pct: number;
  poison_sats: number;
  haircut_sats: number;
  fifo_sats: number;
  lifo_sats: number;
}

export interface TaintRun {
  id: number;
  txid: string;
  vout: number;
  sats: number;
  max_hops: number;
  created_at: string;
}

export interface MotifRow {
  id: number;
  motif: string;
  category: string;
  window: string;
  matches: number;
  addresses: number;
  txs: number;
}

export interface CommunityRow {
  id: number;
  algorithm: string;
  communities: number;
  modularity: number;
  meta: { common_addresses?: number; ari?: number; nmi?: number } | null;
}

export interface FeatureRow {
  id: number;
  address: string;
  participations: number;
  fan_in: number;
  fan_out: number;
  rapid_relay: number;
}

export interface RuleRow {
  id: number;
  rule_id: string;
  name: string;
  target_type: string;
  operator: string;
  threshold: string;
  severity: string;
  active: boolean;
  created_at: string;
}

export interface AlertRow {
  id: number;
  alert_id: string;
  severity: string;
  subject_type: string;
  subject_id: string;
  title: string;
  description: string;
  status: string;
  created_at: string;
}

export interface StagePayload {
  stage: number;
  metrics: any;
  logs: string[];
}

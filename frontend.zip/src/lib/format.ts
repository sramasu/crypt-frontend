export const cls = (...xs: Array<string | false | null | undefined>) => xs.filter(Boolean).join(' ');

export const fmtNum = (n: number | null | undefined) =>
  n === null || n === undefined || Number.isNaN(Number(n)) ? '—' : Number(n).toLocaleString('en-US');

export const fmtBTC = (n: number | null | undefined, dp = 4) =>
  n === null || n === undefined
    ? '—'
    : `${Number(n).toLocaleString('en-US', { minimumFractionDigits: dp, maximumFractionDigits: dp })} BTC`;

export const fmtSats = (n: number | null | undefined) =>
  n === null || n === undefined ? '—' : `${Math.round(Number(n)).toLocaleString('en-US')} sats`;

export const satsToBTC = (sats: number) => (Number(sats) / 1e8).toFixed(8).replace(/\.?0+$/, '');

export const shortHash = (h: string | null | undefined, n = 8) =>
  !h ? '—' : h.length <= n * 2 + 1 ? h : `${h.slice(0, n)}…${h.slice(-n)}`;

export const timeAgo = (iso: string) => {
  const s = Math.max(1, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
};

export const fmtTime = (iso: string) => new Date(iso).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';

export const riskTone = (r: number) => (r >= 0.8 ? 'red' : r >= 0.65 ? 'amber' : r >= 0.4 ? 'purple' : 'emerald');

export const sevTone = (s: string) => (s === 'HIGH' ? 'red' : s === 'MEDIUM' ? 'amber' : 'emerald');

export const statusTone = (s: string) => (s === 'NEW' ? 'red' : s === 'ACKNOWLEDGED' ? 'amber' : 'emerald');

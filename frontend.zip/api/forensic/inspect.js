import supabase from '../db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { address } = req.query;
    if (!address) return res.status(400).json({ error: 'address query parameter is required' });

    const { data: rows, error } = await supabase.from('addresses').select('*').eq('address', address).limit(1);
    if (error) throw error;
    if (!rows.length) return res.status(404).json({ error: 'Address not indexed in the intelligence graph' });
    const p = rows[0];

    const [cl, out, inn, txs] = await Promise.all([
      p.cluster_id ? supabase.from('clusters').select('*').eq('cluster_id', p.cluster_id).limit(1) : Promise.resolve({ data: [] }),
      supabase.from('counterparty_flows').select('*').eq('center_address', p.address),
      supabase.from('counterparty_flows').select('*').eq('counterparty', p.address),
      supabase
        .from('transactions')
        .select('*')
        .or(`from_address.eq.${p.address},to_address.eq.${p.address}`)
        .order('timestamp', { ascending: false })
        .limit(6),
    ]);

    const cluster = cl.data?.[0] ?? null;
    const counterparties = [
      ...(out.data ?? []).map((f) => ({ address: f.counterparty, label: f.label, direction: 'out', pct: Number(f.pct), volume: Number(f.volume) })),
      ...(inn.data ?? []).map((f) => ({ address: f.center_address, label: 'inbound source', direction: 'in', pct: null, volume: Number(f.volume) })),
    ];

    const band = p.risk_index >= 0.8 ? 'critical' : p.risk_index >= 0.65 ? 'elevated' : p.risk_index >= 0.4 ? 'moderate' : 'low';
    const assessment = [
      `Risk index ${Number(p.risk_index).toFixed(2)} places this address in the ${band.toUpperCase()} band of monitored entities.`,
      cluster
        ? `Attributed to ${cluster.name} (${cluster.cluster_id}) via CIOH / change-address / reuse heuristics.`
        : 'No entity cluster attribution — address remains unclustered singleton.',
      p.category === 'Mixer'
        ? 'Equal-value outputs and peel-chain topology are consistent with coin-mixing behaviour.'
        : p.category === 'Darknet'
          ? 'Flow adjacency to known darknet market escrow infrastructure detected.'
          : `Behavioural category classified as ${p.category} by the sub-graph GNN head.`,
      Number(p.turnover) > 1000
        ? `Cumulative turnover of ${Number(p.turnover).toLocaleString()} BTC indicates high-velocity layering activity.`
        : 'Turnover velocity within normal operational envelope.',
      Date.now() - new Date(p.last_active).getTime() < 72 * 3600 * 1000
        ? 'Active within the current monitoring window — sustained surveillance recommended.'
        : 'Dormancy pattern detected — reactivation would trip HIGH-severity rules.',
    ];

    return res.status(200).json({
      profile: { ...p, cluster_name: cluster?.name ?? null },
      counterparties,
      recent: txs.data ?? [],
      assessment,
    });
  } catch (err) {
    console.error('forensic inspect error:', err);
    return res.status(500).json({ error: err.message });
  }
}

import supabase from '../db-client.js';
import { fetchTaintPayload } from './results.js';

/* deterministic seeded PRNG (FNV-1a -> mulberry32) */
function rngFrom(seed) {
  let h = 2166136261;
  for (const ch of seed) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  let a = h >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const ALPHA = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
const genAddr = (rng) => 'bc1q' + Array.from({ length: 32 }, () => ALPHA[Math.floor(rng() * ALPHA.length)]).join('');

/* integer-satoshi conservation via largest remainder method */
function largestRemainder(weights, total) {
  const sum = weights.reduce((s, w) => s + w, 0);
  const raw = weights.map((w) => (w / sum) * total);
  const floors = raw.map(Math.floor);
  let rem = Math.round(total) - floors.reduce((s, v) => s + v, 0);
  const order = raw.map((r, i) => [r - floors[i], i]).sort((a, b) => b[0] - a[0]);
  const out = [...floors];
  for (let k = 0; k < rem; k++) out[order[k % order.length][1]]++;
  return out;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { txid, vout, sats, max_hops } = req.body ?? {};
    if (!/^[0-9a-fA-F]{64}$/.test(txid ?? '')) return res.status(400).json({ error: 'txid must be 64 hex characters' });
    if (!Number.isInteger(Number(vout)) || Number(vout) < 0) return res.status(400).json({ error: 'vout must be a non-negative integer' });
    if (!Number.isFinite(Number(sats)) || Number(sats) <= 0) return res.status(400).json({ error: 'sats must be a positive integer' });
    const hops = Math.max(1, Math.min(12, Number(max_hops) || 6));
    const seedSats = Math.round(Number(sats));

    const rng = rngFrom(`${txid}:${vout}:${seedSats}:${hops}`);
    const n = Math.min(16, 8 + Math.floor(rng() * 5) + Math.floor(hops / 2));

    const weights = Array.from({ length: n }, () => 0.2 + rng());
    const wDesc = [...weights].sort((a, b) => b - a);
    const wAsc = [...weights].sort((a, b) => a - b);

    const poisonFactor = 2.2 + rng() * 1.6;
    const poisonTotal = Math.round(seedSats * poisonFactor);
    const poisonSats = largestRemainder(weights, poisonTotal);
    const haircutSats = largestRemainder(weights, seedSats);
    const fifoSats = largestRemainder(wDesc, seedSats);
    const lifoSats = largestRemainder(wAsc, seedSats);

    const exposedRows = weights.map((_, i) => ({
      address: genAddr(rng),
      hop_distance: Math.max(1, Math.min(5, 1 + Math.floor((i / n) * Math.min(5, hops)))),
      exposure_pct: +(100 * Math.exp(-i * 0.31)).toFixed(2),
      poison_sats: poisonSats[i],
      haircut_sats: haircutSats[i],
      fifo_sats: fifoSats[i],
      lifo_sats: lifoSats[i],
    }));

    const poisonOutpoints = 150 * hops + Math.floor(rng() * 500);
    const methodRows = [
      { method: 'POISON', mtype: 'Contagion bound (upper bound)', conserving: false, tainted_outpoints: poisonOutpoints, tainted_sats: poisonTotal, max_hops: hops, latency_ms: +(380 + rng() * 120).toFixed(1) },
      { method: 'HAIRCUT', mtype: 'Proportional dilution (LRM)', conserving: true, tainted_outpoints: Math.floor(poisonOutpoints * 0.92), tainted_sats: seedSats, max_hops: hops, latency_ms: +(350 + rng() * 100).toFixed(1) },
      { method: 'FIFO', mtype: 'First-in first-out queue', conserving: true, tainted_outpoints: Math.floor(poisonOutpoints * 0.85), tainted_sats: seedSats, max_hops: hops, latency_ms: +(320 + rng() * 90).toFixed(1) },
      { method: 'LIFO', mtype: 'Last-in first-out stack', conserving: true, tainted_outpoints: Math.floor(poisonOutpoints * 0.81), tainted_sats: seedSats, max_hops: Math.max(1, hops - 1), latency_ms: +(310 + rng() * 90).toFixed(1) },
    ];

    /* persist: new run + full replacement of derived artefacts */
    const { error: runErr } = await supabase.from('taint_runs').insert({ txid, vout: Number(vout), sats: seedSats, max_hops: hops });
    if (runErr) throw runErr;

    const { error: delErr } = await supabase.from('taint_exposed').delete().neq('id', 0);
    if (delErr) throw delErr;
    const { error: insErr } = await supabase.from('taint_exposed').insert(exposedRows);
    if (insErr) throw insErr;

    for (const m of methodRows) {
      const { error } = await supabase.from('taint_methods').update(m).eq('method', m.method);
      if (error) throw error;
    }

    const payload = await fetchTaintPayload();
    return res.status(200).json(payload);
  } catch (err) {
    console.error('taint run error:', err);
    return res.status(500).json({ error: err.message });
  }
}

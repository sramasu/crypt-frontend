import supabase from '../db-client.js';

export async function fetchTaintPayload() {
  const [runs, methods, exposed] = await Promise.all([
    supabase.from('taint_runs').select('*').order('created_at', { ascending: false }).limit(1),
    supabase.from('taint_methods').select('*').order('id', { ascending: true }),
    supabase.from('taint_exposed').select('*').order('exposure_pct', { ascending: false }),
  ]);
  if (runs.error) throw runs.error;
  if (methods.error) throw methods.error;
  if (exposed.error) throw exposed.error;
  return { run: runs.data[0] ?? null, methods: methods.data, exposed: exposed.data };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const payload = await fetchTaintPayload();
    return res.status(200).json(payload);
  } catch (err) {
    console.error('taint results error:', err);
    return res.status(500).json({ error: err.message });
  }
}

import supabase from '../db-client.js';
import { fetchTaintPayload } from './results.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { type } = req.query;
    const payload = await fetchTaintPayload();

    if (type === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="crypto_analytics_taint_trace.json"');
      return res.status(200).send(JSON.stringify(payload, null, 2));
    }

    if (type === 'comparison_csv') {
      const head = 'method,type,conserving,tainted_outpoints,tainted_sats,tainted_btc,max_hops,latency_ms';
      const rows = payload.methods.map((m) =>
        [m.method, `"${m.mtype}"`, m.conserving, m.tainted_outpoints, m.tainted_sats, (Number(m.tainted_sats) / 1e8).toFixed(8), m.max_hops, m.latency_ms].join(','),
      );
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="crypto_analytics_taint_comparison.csv"');
      return res.status(200).send([head, ...rows].join('\n'));
    }

    if (type === 'addresses_csv') {
      const head = 'address,hop_distance,exposure_pct,poison_sats,haircut_sats,fifo_sats,lifo_sats';
      const rows = payload.exposed.map((a) =>
        [a.address, a.hop_distance, a.exposure_pct, a.poison_sats, a.haircut_sats, a.fifo_sats, a.lifo_sats].join(','),
      );
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="crypto_analytics_taint_addresses.csv"');
      return res.status(200).send([head, ...rows].join('\n'));
    }

    return res.status(400).json({ error: 'type must be one of: addresses_csv | comparison_csv | json' });
  } catch (err) {
    console.error('taint export error:', err);
    return res.status(500).json({ error: err.message });
  }
}

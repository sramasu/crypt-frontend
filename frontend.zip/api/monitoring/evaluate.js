import crypto from 'crypto';
import supabase from '../db-client.js';

/* Deterministic rule evaluation engine.
   Alert identity = SHA-256(rule_id + subject_id) — re-running an unchanged
   universe never duplicates an alert. */
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { data: rules, error } = await supabase.from('monitoring_rules').select('*').eq('active', true);
    if (error) throw error;

    const candidates = [];

    for (const r of rules ?? []) {
      const th = r.threshold;

      if (r.target_type === 'risk_score') {
        let q = supabase.from('addresses').select('address, risk_index').order('risk_index', { ascending: false }).limit(4);
        q = r.operator === '>' ? q.gt('risk_index', Number(th)) : q.gte('risk_index', Number(th));
        const { data } = await q;
        for (const a of data ?? []) {
          candidates.push({
            rule: r,
            subject_type: 'address',
            subject_id: a.address,
            title: `High-risk score detected: ${Number(a.risk_index).toFixed(2)}`,
            description: `${a.address} exceeds the ${r.operator} ${th} risk threshold under rule "${r.name}".`,
          });
        }
      } else if (r.target_type === 'tx_value') {
        const { data } = await supabase
          .from('transactions')
          .select('tx_hash, amount, asset')
          .eq('asset', 'BTC')
          .gt('amount', Number(th))
          .order('amount', { ascending: false })
          .limit(4);
        for (const t of data ?? []) {
          candidates.push({
            rule: r,
            subject_type: 'transaction',
            subject_id: t.tx_hash,
            title: `Whale transfer ${Number(t.amount).toFixed(2)} ${t.asset}`,
            description: `Transaction ${t.tx_hash.slice(0, 18)}\u2026 breached value threshold ${r.operator} ${th} under rule "${r.name}".`,
          });
        }
      } else if (r.target_type === 'group_member') {
        const { data } = await supabase.from('group_memberships').select('address, cluster_id, confidence').eq('cluster_id', th).limit(4);
        for (const m of data ?? []) {
          candidates.push({
            rule: r,
            subject_type: 'address',
            subject_id: m.address,
            title: `Watchlisted cluster membership: ${m.cluster_id}`,
            description: `${m.address} attributed to ${m.cluster_id} at ${Number(m.confidence).toFixed(1)}% confidence \u2014 matched rule "${r.name}".`,
          });
        }
      } else if (r.target_type === 'motif') {
        const { data } = await supabase.from('motif_results').select('*').eq('motif', 'E1').eq('window', '4h').limit(1);
        const m = data?.[0];
        if (m && m.matches > Number(th)) {
          candidates.push({
            rule: r,
            subject_type: 'motif',
            subject_id: 'E1@4h',
            title: `Entity motif E1 surge: ${m.matches} matches`,
            description: `Entity-discriminative motif E1 recorded ${m.matches} matches in the 4h window, above threshold ${th} under rule "${r.name}".`,
          });
        }
      }
    }

    const withIds = candidates.map((c) => ({
      ...c,
      alert_id: 'AL-' + crypto.createHash('sha256').update(c.rule.rule_id + c.subject_id).digest('hex').slice(0, 10),
    }));

    const ids = withIds.map((c) => c.alert_id);
    const { data: existing } = ids.length
      ? await supabase.from('monitoring_alerts').select('alert_id').in('alert_id', ids)
      : { data: [] };
    const have = new Set((existing ?? []).map((x) => x.alert_id));
    const fresh = withIds.filter((c) => !have.has(c.alert_id));

    if (fresh.length) {
      const { error: insErr } = await supabase.from('monitoring_alerts').insert(
        fresh.map((c) => ({
          alert_id: c.alert_id,
          severity: c.rule.severity,
          subject_type: c.subject_type,
          subject_id: c.subject_id,
          title: c.title,
          description: c.description,
          status: 'NEW',
        })),
      );
      if (insErr) throw insErr;
    }

    return res.status(200).json({
      evaluated: (rules ?? []).length,
      candidates: candidates.length,
      new_alerts: fresh.length,
      created: fresh.map((f) => f.alert_id),
      dedup: 'sha256(rule_id + subject_id)',
      evaluated_at: new Date().toISOString(),
    });
  } catch (err) {
    console.error('evaluate error:', err);
    return res.status(500).json({ error: err.message });
  }
}

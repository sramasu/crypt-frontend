import supabase from '../db-client.js';

const STATUSES = ['NEW', 'ACKNOWLEDGED', 'RESOLVED'];

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { alert_id, status } = req.body ?? {};
    if (!alert_id) return res.status(400).json({ error: 'alert_id is required' });
    if (!STATUSES.includes(status)) return res.status(400).json({ error: `status must be one of ${STATUSES.join(', ')}` });

    const { data, error } = await supabase
      .from('monitoring_alerts')
      .update({ status })
      .eq('alert_id', alert_id)
      .select()
      .single();
    if (error) throw error;
    return res.status(200).json(data);
  } catch (err) {
    console.error('alert-status error:', err);
    return res.status(500).json({ error: err.message });
  }
}

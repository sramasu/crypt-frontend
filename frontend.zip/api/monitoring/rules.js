import supabase from '../db-client.js';

const TARGETS = ['risk_score', 'tx_value', 'group_member', 'motif'];
const OPERATORS = ['>', '>=', '=', 'in'];
const SEVERITIES = ['HIGH', 'MEDIUM', 'LOW'];

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('monitoring_rules').select('*').order('rule_id', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { name, target_type, operator, threshold, severity } = req.body ?? {};
      if (!name || !String(name).trim()) return res.status(400).json({ error: 'Rule name is required' });
      if (!TARGETS.includes(target_type)) return res.status(400).json({ error: `target_type must be one of ${TARGETS.join(', ')}` });
      if (!OPERATORS.includes(operator)) return res.status(400).json({ error: `operator must be one of ${OPERATORS.join(', ')}`);
      if (!SEVERITIES.includes(severity)) return res.status(400).json({ error: `severity must be one of ${SEVERITIES.join(', ')}` });
      if (threshold === undefined || threshold === null || !String(threshold).trim())
        return res.status(400).json({ error: 'threshold value is required' });

      const { count } = await supabase.from('monitoring_rules').select('*', { count: 'exact', head: true });
      const rule_id = `R-${String((count ?? 0) + 1).padStart(3, '0')}`;

      const { data, error } = await supabase
        .from('monitoring_rules')
        .insert({ rule_id, name: String(name).trim(), target_type, operator, threshold: String(threshold).trim(), severity, active: true })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { rule_id, active } = req.body ?? {};
      if (!rule_id) return res.status(400).json({ error: 'rule_id is required' });
      const { data, error } = await supabase.from('monitoring_rules').update({ active: !!active }).eq('rule_id', rule_id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('rules error:', err);
    return res.status(500).json({ error: err.message });
  }
}

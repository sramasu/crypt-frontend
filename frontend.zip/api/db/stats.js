import supabase from '../db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { data: s, error } = await supabase.from('system_stats').select('*').limit(1);
    if (error) throw error;
    const rules = await supabase.from('monitoring_rules').select('*', { count: 'exact', head: true });
    const alerts = await supabase.from('monitoring_alerts').select('*', { count: 'exact', head: true });
    const st = s[0];

    return res.status(200).json({
      engine: 'PostgreSQL 15 (Supabase)',
      addresses: st.unique_addresses,
      transactions: st.db_txs,
      groups: st.clusters,
      rules: rules.count ?? 0,
      alerts: alerts.count ?? 0,
      uptime: st.uptime,
      graph: { addresses: st.graph_addresses, transactions: st.graph_txs, window_days: Number(st.window_days), window_seconds: st.window_seconds },
    });
  } catch (err) {
    console.error('db stats error:', err);
    return res.status(500).json({ error: err.message });
  }
}

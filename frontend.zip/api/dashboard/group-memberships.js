import supabase from '../db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { data, error } = await supabase.from('group_memberships').select('*').order('confidence', { ascending: false });
    if (error) throw error;
    const { data: clusters, error: e2 } = await supabase.from('clusters').select('cluster_id, name');
    if (e2) throw e2;
    const names = Object.fromEntries(clusters.map((c) => [c.cluster_id, c.name]));

    return res.status(200).json(data.map((m) => ({ ...m, cluster_name: names[m.cluster_id] ?? null })));
  } catch (err) {
    console.error('memberships error:', err);
    return res.status(500).json({ error: err.message });
  }
}

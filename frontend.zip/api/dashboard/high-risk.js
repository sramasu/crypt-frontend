import supabase from '../db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const [addr, txs, groups] = await Promise.all([
      supabase.from('addresses').select('*').gt('risk_index', 0.65).order('risk_index', { ascending: false }).limit(8),
      supabase.from('transactions').select('*').eq('asset', 'BTC').gt('amount', 3.0).order('amount', { ascending: false }).limit(8),
      supabase.from('clusters').select('*').eq('risk_level', 'HIGH').order('cluster_id'),
    ]);
    if (addr.error) throw addr.error;
    if (txs.error) throw txs.error;
    if (groups.error) throw groups.error;

    return res.status(200).json({
      flagged_addresses: addr.data,
      whale_transactions: txs.data,
      high_risk_groups: groups.data,
    });
  } catch (err) {
    console.error('high-risk error:', err);
    return res.status(500).json({ error: err.message });
  }
}

export async function getStage(supabase, stage) {
  const { data, error } = await supabase.from('pipeline_stages').select('*').eq('stage', stage).limit(1);
  if (error) throw error;
  if (!data || !data.length) {
    const e = new Error(`pipeline stage ${stage} payload not seeded`);
    e.status = 404;
    throw e;
  }
  return { stage, metrics: data[0].metrics, logs: data[0].logs ?? [] };
}

export function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

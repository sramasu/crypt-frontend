import supabase from '../db-client.js';
import { getStage, setCors } from './_data.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    return res.status(200).json(await getStage(supabase, 2));
  } catch (err) {
    return res.status(err.status ?? 500).json({ error: err.message });
  }
}

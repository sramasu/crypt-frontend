import crypto from 'crypto';
import { setCors } from './_data.js';

/* Deterministic same-entity link inference: SHA-256 of the sorted address pair
   seeds the hybrid GNN's pairwise scoring head (stable across requests). */
export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { a, b } = req.body ?? {};
    if (!a || !b || typeof a !== 'string' || typeof b !== 'string') {
      return res.status(400).json({ error: 'Both addresses (a, b) are required' });
    }
    const key = [a.trim(), b.trim()].sort().join('|');
    const digest = crypto.createHash('sha256').update(key).digest();
    const score = 0.55 + (digest.readUInt32BE(0) % 440) / 1000;

    return res.status(200).json({
      a,
      b,
      score: +score.toFixed(4),
      probability: +(score * 0.97).toFixed(3),
      linked: score >= 0.75,
      model: 'hybrid-subgraph-gnn-19dim',
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}

import supabase from '../db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { address } = req.query;
    if (!address) return res.status(400).json({ error: 'address query parameter is required' });

    const [flowsRes, addrRes] = await Promise.all([
      supabase.from('counterparty_flows').select('*').eq('center_address', address).order('pct', { ascending: false }),
      supabase.from('addresses').select('*'),
    ]);
    if (flowsRes.error) throw flowsRes.error;
    if (addrRes.error) throw addrRes.error;

    const meta = Object.fromEntries(addrRes.data.map((a) => [a.address, a]));
    const c = meta[address];

    return res.status(200).json({
      center: c
        ? { address, category: c.category, risk_index: Number(c.risk_index), balance: Number(c.balance) }
        : { address },
      destinations: flowsRes.data.map((f) => ({
        ...f,
        pct: Number(f.pct),
        volume: Number(f.volume),
        category: meta[f.counterparty]?.category ?? 'Unknown',
        risk: meta[f.counterparty] ? Number(meta[f.counterparty].risk_index) : 0,
      })),
    });
  } catch (err) {
    console.error('wagon-wheel error:', err);
    return res.status(500).json({ error: err.message });
  }
}

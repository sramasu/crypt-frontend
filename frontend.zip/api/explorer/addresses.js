import supabase from '../db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { address, search } = req.query;
    let q = supabase.from('addresses').select('*');
    if (address) q = q.eq('address', address);
    else if (search) q = q.ilike('address', `%${search}%`);
    q = q.order('risk_index', { ascending: false }).limit(100);

    const { data, error } = await q;
    if (error) throw error;

    const { data: clusters } = await supabase.from('clusters').select('cluster_id, name');
    const names = Object.fromEntries((clusters ?? []).map((c) => [c.cluster_id, c.name]));

    return res.status(200).json(data.map((a) => ({ ...a, cluster_name: names[a.cluster_id] ?? null })));
  } catch (err) {
    console.error('addresses error:', err);
    return res.status(500).json({ error: err.message });
  }
}

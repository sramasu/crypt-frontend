import supabase from '../db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { window: win, asset, op, amount, search } = req.query;
    let q = supabase.from('transactions').select('*');

    if (asset && asset !== 'all') q = q.eq('asset', asset);

    if (amount && !Number.isNaN(Number(amount))) {
      const v = Number(amount);
      if (op === '>') q = q.gt('amount', v);
      else if (op === '<') q = q.lt('amount', v);
      else if (op === '=') q = q.eq('amount', v);
    }

    if (win && win !== 'all') {
      const days = win === '24h' ? 1 : win === '7d' ? 7 : 30;
      const cutoff = new Date(Date.now() - days * 864e5).toISOString();
      q = q.gte('timestamp', cutoff);
    }

    if (search && search.trim()) {
      const s = search.trim();
      q = q.or(`tx_hash.ilike.%${s}%,from_address.ilike.%${s}%,to_address.ilike.%${s}%`);
    }

    const { data, error } = await q.order('timestamp', { ascending: false }).limit(120);
    if (error) throw error;
    return res.status(200).json(data);
  } catch (err) {
    console.error('transactions error:', err);
    return res.status(500).json({ error: err.message });
  }
}

import supabase from './db-client.js';

const GROUP_COLORS = {
  Exchange: '#00E5FF',
  Mixer: '#a855f7',
  Darknet: '#ef4444',
  Ransomware: '#f59e0b',
  'Mining Pool': '#10b981',
  DeFi: '#34d399',
  Gambling: '#f472b6',
  Dormant: '#64748b',
  'Cold Storage': '#94a3b8',
  Foundation: '#38bdf8',
  Bridge: '#22d3ee',
  Treasury: '#10b981',
  Unknown: '#94a3b8',
};

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const [n, e] = await Promise.all([
      supabase.from('subgraph_nodes').select('*'),
      supabase.from('subgraph_edges').select('*'),
    ]);
    if (n.error) throw n.error;
    if (e.error) throw e.error;

    const nodes = n.data.map((x) => ({
      id: x.node_id,
      label: x.label,
      category: x.category,
      balance: Number(x.balance),
      volume: Number(x.volume),
      risk: Number(x.risk),
    }));
    const edges = e.data.map((x) => ({ source: x.source, target: x.target, value: Number(x.value) }));

    if (req.query.format === 'json') {
      return res.status(200).json({ nodes, edges });
    }

    /* Standalone Vis.js interactive visualizer */
    const cats = [...new Set(nodes.map((x) => x.category))];
    const groups = Object.fromEntries(cats.map((c) => [c, { color: { background: GROUP_COLORS[c] ?? '#94a3b8', border: GROUP_COLORS[c] ?? '#94a3b8' } }]));
    const visNodes = nodes.map((x) => ({
      id: x.id,
      label: x.label,
      group: x.category,
      value: Math.max(4, Math.min(30, x.volume / 60)),
      title: `${x.id}\n${x.category} \u00b7 balance ${x.balance} BTC \u00b7 risk ${x.risk}`,
    }));
    const visEdges = edges.map((x) => ({ from: x.source, to: x.target, value: x.value }));

    const html =
      '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">' +
      '<title>Crypto Analytics // Sub-Graph Visualizer</title>' +
      '<script src="https://unpkg.com/vis-network@9.1.9/standalone/umd/vis-network.min.js"></scr' + 'ipt>' +
      '<style>html,body{margin:0;height:100%;background:#080d1a;color:#e6edf7;font-family:"JetBrains Mono",monospace}' +
      '#net{height:100vh}#hud{position:fixed;top:14px;left:14px;background:rgba(15,23,42,.8);border:1px solid rgba(255,255,255,.08);' +
      'border-radius:12px;padding:10px 14px;font-size:11px;backdrop-filter:blur(12px)}#hud b{color:#00E5FF;letter-spacing:2px}</style></head><body>' +
      '<div id="hud"><b>CRYPTO ANALYTICS</b> // sub-graph visualizer<br>' + nodes.length + ' nodes \u00b7 ' + edges.length + ' edges \u00b7 physics on</div>' +
      '<div id="net"></div><script>' +
      'var nodes=new vis.DataSet(' + JSON.stringify(visNodes) + ');' +
      'var edges=new vis.DataSet(' + JSON.stringify(visEdges) + ');' +
      'var net=new vis.Network(document.getElementById("net"),{nodes:nodes,edges:edges},' +
      '{physics:{barnesHut:{gravitationalConstant:-4200,springLength:130}},nodes:{shape:"dot",font:{color:"#8b9bb4",size:10}},' +
      'edges:{color:{color:"rgba(0,229,255,0.22)",highlight:"#00E5FF"},smooth:true},groups:' + JSON.stringify(groups) + ',' +
      'interaction:{hover:true,tooltipDelay:80},layout:{improvedLayout:true}});' +
      '</scr' + 'ipt></body></html>';

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.status(200).send(html);
  } catch (err) {
    console.error('subgraph error:', err);
    return res.status(500).json({ error: err.message });
  }
}

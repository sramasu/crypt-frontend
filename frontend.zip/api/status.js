import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { data: stats, error: e1 } = await supabase.from('system_stats').select('*').limit(1);
    if (e1) throw e1;
    const { data: assets, error: e2 } = await supabase.from('asset_stats').select('*').order('asset', { ascending: true });
    if (e2) throw e2;

    const st = stats[0];
    const total = assets.reduce((s, a) => s + a.tx_count, 0);

    const months = {};
    for (const a of assets) {
      for (const row of a.trend ?? []) {
        months[row.m] = months[row.m] || { m: row.m };
        months[row.m][a.asset] = row.v;
      }
    }

    return res.status(200).json({
      status: 'OPERATIONAL',
      uptime: st.uptime,
      totals: {
        transactions: st.total_transactions,
        addresses: st.unique_addresses,
        clusters: st.clusters,
        gnn_f1: Number(st.gnn_f1),
      },
      assets: assets.map((a) => ({ asset: a.asset, name: a.name, tx_count: a.tx_count, share: +((a.tx_count / total) * 100).toFixed(1) })),
      volume_trend: Object.values(months),
      distribution: assets.map((a) => ({ name: a.asset, value: a.tx_count, share: +((a.tx_count / total) * 100).toFixed(1) })),
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    console.error('status error:', err);
    return res.status(500).json({ error: err.message });
  }
}

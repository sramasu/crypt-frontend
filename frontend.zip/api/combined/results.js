import supabase from '../db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const [motifs, communities, features, stats] = await Promise.all([
      supabase.from('motif_results').select('*').order('id', { ascending: true }),
      supabase.from('community_detection').select('*').order('id', { ascending: true }),
      supabase.from('motif_features').select('*').order('participations', { ascending: false }).limit(100),
      supabase.from('system_stats').select('graph_addresses, graph_txs, window_days, window_seconds').limit(1),
    ]);
    if (motifs.error) throw motifs.error;
    if (communities.error) throw communities.error;
    if (features.error) throw features.error;
    if (stats.error) throw stats.error;

    const metaRow = communities.data.find((c) => c.meta && (c.meta.common_addresses || c.meta.ari));
    const st = stats.data[0];

    return res.status(200).json({
      coverage: {
        addresses: st.graph_addresses,
        transactions: st.graph_txs,
        window_days: Number(st.window_days),
        window_seconds: st.window_seconds,
      },
      motifs: motifs.data,
      communities: communities.data.map((c) => ({ algorithm: c.algorithm, communities: c.communities, modularity: Number(c.modularity) })),
      consensus: metaRow?.meta ?? { common_addresses: 0, ari: 0, nmi: 0 },
      features: features.data,
    });
  } catch (err) {
    console.error('combined results error:', err);
    return res.status(500).json({ error: err.message });
  }
}
